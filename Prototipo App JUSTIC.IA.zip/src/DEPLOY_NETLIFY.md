# 🚀 Guía de Deployment a Netlify - JUSTIC.IA

## 📋 Pasos para subir tu aplicación a Netlify

### Opción 1: Drag & Drop (Más fácil)

1. **Preparar archivos localmente:**
   ```bash
   # Si tienes Node.js instalado
   npm install
   npm run build
   
   # Si no tienes Node.js, puedes usar los archivos tal como están
   ```

2. **Ir a Netlify:**
   - Ve a https://netlify.com
   - Crea una cuenta gratuita
   - En el dashboard, arrastra toda la carpeta de tu proyecto
   - ¡Listo! Tu app estará online

### Opción 2: Deploy desde GitHub (Recomendado)

1. **Subir código a GitHub:**
   ```bash
   # Crear repositorio en GitHub primero
   git init
   git add .
   git commit -m "Initial commit - JUSTIC.IA app"
   git branch -M main
   git remote add origin https://github.com/tu-usuario/justicia-app.git
   git push -u origin main
   ```

2. **Conectar con Netlify:**
   - Ve a https://netlify.com
   - Clic en "Import from Git"
   - Conecta tu GitHub
   - Selecciona tu repositorio "justicia-app"
   - Configuración automática:
     - Build command: `npm run build`
     - Publish directory: `dist`
   - ¡Deploy automático!

### Opción 3: Netlify CLI (Avanzado)

```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
netlify deploy --prod --dir=dist
```

## 🔧 Configuración Automática

Tu aplicación ya incluye:
- ✅ **netlify.toml** - Configuración automática
- ✅ **_redirects** - Rutas para SPA
- ✅ **manifest.json** - PWA
- ✅ **Service Worker** - Funcionamiento offline
- ✅ **Iconos** - Para instalación móvil

## 📱 Características PWA Incluidas

Una vez desplegado, tu app tendrá:
- **Instalación en móviles** - Botón "Agregar a pantalla inicio"
- **Funcionamiento offline** - Cache automático
- **Notificaciones push** - Para alertas
- **Acceso a cámara/GPS** - Para reportes

## 🌐 Variables de Entorno (Opcional)

Si quieres conectar Supabase real:

1. **En Netlify Dashboard:**
   - Ir a "Site settings"
   - "Environment variables"
   - Agregar:
     ```
     NEXT_PUBLIC_SUPABASE_URL=tu_url_de_supabase
     NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_key_anonima
     ```

## 🎯 URLs de tu aplicación

Después del deploy obtendrás:
- **URL temporal**: https://random-name-123.netlify.app
- **URL personalizada**: https://tu-dominio-personalizado.netlify.app

## 📊 Métricas y Analytics

Netlify te dará automáticamente:
- Estadísticas de visitas
- Performance metrics
- Error tracking
- Form submissions (si los tienes)

## 🔒 Seguridad incluida

Tu app incluye headers de seguridad:
- X-Frame-Options
- X-Content-Type-Options
- X-XSS-Protection
- Content Security Policy

## 🚨 Troubleshooting

### Si el build falla:
```bash
# Comprobar localmente
npm install
npm run build

# Si hay errores de TypeScript
npm run build --skip-type-check
```

### Si las rutas no funcionan:
- Verificar que existe `/public/_redirects`
- Verificar configuración en `netlify.toml`

### Si PWA no funciona:
- Verificar que `manifest.json` esté en `/public/`
- Verificar que `sw.js` esté en `/public/`
- Comprobar HTTPS (requerido para PWA)

## 📞 Soporte

Si tienes problemas:
1. Revisa los logs de build en Netlify
2. Verifica la consola del navegador
3. Comprueba que todos los archivos estén subidos

¡Tu aplicación JUSTIC.IA estará lista para ayudar a mejorar la seguridad ciudadana en Perú! 🇵🇪