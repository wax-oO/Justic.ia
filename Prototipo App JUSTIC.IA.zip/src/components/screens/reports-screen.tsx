import React, { useState } from 'react';
import { FileText, Download, QrCode, Eye, Clock, CheckCircle, AlertCircle, Plus, Home, ArrowLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '../ui/dialog';

interface ReportsScreenProps {
  userData?: any;
  onNavigate?: (screen: string) => void;
}

export function ReportsScreen({ userData, onNavigate }: ReportsScreenProps) {
  const [reports] = useState<Report[]>([
    {
      id: '1',
      code: 'JA-2024-001234',
      type: 'Robo',
      status: 'in_progress',
      date: '2024-01-15',
      location: 'Av. Universitaria, Comas',
      description: 'Robo de celular en transporte público',
      evidence: ['foto1.jpg', 'audio1.mp3']
    },
    {
      id: '2',
      code: 'JA-2024-001233',
      type: 'Acoso',
      status: 'resolved',
      date: '2024-01-14',
      location: 'Estación Metro, Lima Centro',
      description: 'Acoso verbal en estación de metro',
      evidence: ['video1.mp4']
    },
    {
      id: '3',
      code: 'JA-2024-001232',
      type: 'Agresión',
      status: 'pending',
      date: '2024-01-13',
      location: 'Parque Central, San Juan de Lurigancho',
      description: 'Agresión física en parque público',
      evidence: ['foto2.jpg', 'foto3.jpg']
    }
  ]);

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'pending':
        return { label: 'Pendiente', color: 'bg-yellow-100 text-yellow-800', icon: Clock };
      case 'in_progress':
        return { label: 'En Proceso', color: 'bg-blue-100 text-blue-800', icon: AlertCircle };
      case 'resolved':
        return { label: 'Resuelto', color: 'bg-green-100 text-green-800', icon: CheckCircle };
      case 'rejected':
        return { label: 'Rechazado', color: 'bg-red-100 text-red-800', icon: AlertCircle };
      default:
        return { label: 'Desconocido', color: 'bg-gray-100 text-gray-800', icon: Clock };
    }
  };

  const handleDownloadPDF = (reportCode: string) => {
    // Simular descarga de PDF
    console.log(`Descargando certificado PDF para ${reportCode}`);
    alert(`📄 Descargando certificado para denuncia ${reportCode}`);
  };

  const handleShowQR = (reportCode: string) => {
    console.log(`Mostrando QR para ${reportCode}`);
  };

  return (
    <div className="p-4 pb-20 bg-background">
      {/* Header Minimalista */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl">Mis Denuncias</h2>
          <p className="text-muted-foreground">Historial de reportes y seguimiento</p>
        </div>
        <Button
          onClick={() => onNavigate?.('create-report')}
          className="flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Nueva</span>
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">3</div>
            <div className="text-sm text-muted-foreground">Total</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">1</div>
            <div className="text-sm text-muted-foreground">En Proceso</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">1</div>
            <div className="text-sm text-muted-foreground">Resueltas</div>
          </CardContent>
        </Card>
      </div>

      {/* Reports List */}
      <div className="space-y-4">
        {reports.map((report) => {
          const statusInfo = getStatusInfo(report.status);
          const StatusIcon = statusInfo.icon;
          
          return (
            <Card key={report.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-base">{report.type}</CardTitle>
                    <p className="text-sm text-muted-foreground">Código: {report.code}</p>
                  </div>
                  <Badge className={statusInfo.color}>
                    <StatusIcon className="w-3 h-3 mr-1" />
                    {statusInfo.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span>{new Date(report.date).toLocaleDateString('es-PE')}</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <Eye className="w-4 h-4 text-muted-foreground mt-0.5" />
                    <span className="text-muted-foreground">{report.location}</span>
                  </div>
                  <p className="text-sm">{report.description}</p>
                  <div className="flex items-center gap-2 text-sm">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{report.evidence.length} evidencia(s)</span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1">
                        <QrCode className="w-4 h-4 mr-2" />
                        Ver QR
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Código QR - {report.code}</DialogTitle>
                        <DialogDescription>
                          Este código QR contiene la información de verificación de tu denuncia.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="text-center py-8">
                        <div className="w-48 h-48 bg-gray-100 mx-auto mb-4 flex items-center justify-center border-2 border-dashed rounded-lg">
                          <QrCode className="w-24 h-24 text-gray-400" />
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Escanea este código para verificar la autenticidad de la denuncia
                        </p>
                      </div>
                    </DialogContent>
                  </Dialog>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleDownloadPDF(report.code)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {reports.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg mb-2">No tienes denuncias registradas</h3>
          <p className="text-muted-foreground mb-6">
            Cuando realices tu primera denuncia aparecerá aquí
          </p>
          <Button onClick={() => onNavigate?.('create-report')}>
            <Plus className="w-4 h-4 mr-2" />
            Crear Primera Denuncia
          </Button>
        </div>
      )}

      {/* Botón flotante para nueva denuncia */}
      {reports.length > 0 && (
        <Button
          onClick={() => onNavigate?.('create-report')}
          className="fixed bottom-20 right-4 w-14 h-14 rounded-full shadow-lg bg-red-600 hover:bg-red-700"
          size="sm"
        >
          <Plus className="w-6 h-6" />
        </Button>
      )}

      {/* Información adicional */}
      <Card className="mt-6 bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-blue-800 mb-1">
                💡 Consejo Legal
              </h4>
              <p className="text-sm text-blue-700">
                Mantén siempre copias de tus denuncias y códigos QR. Son documentos oficiales que pueden ser requeridos en procesos legales.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}