import React, { useState } from 'react';
import { User, Shield, Phone, Mail, MapPin, Settings, LogOut, CheckCircle, AlertCircle, Camera, Bell, Lock, Eye, Award, History, HelpCircle, FileText, Smartphone, Home, ArrowLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Switch } from '../ui/switch';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Separator } from '../ui/separator';
import { Alert, AlertDescription } from '../ui/alert';

interface ProfileScreenProps {
  userData?: any;
  onLogout: () => void;
  isEmergencyMode?: boolean;
  onNavigate?: (screen: string) => void;
}

export function ProfileScreen({ userData, onLogout, isEmergencyMode, onNavigate }: ProfileScreenProps) {
  const [showDNIVerification, setShowDNIVerification] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showEmergencyContacts, setShowEmergencyContacts] = useState(false);
  const [showSecuritySettings, setShowSecuritySettings] = useState(false);

  // Datos del perfil con información más detallada
  const profile = userData ? {
    id: userData.id,
    name: `${userData.nombre} ${userData.apellidos}`,
    dni: userData.dni,
    phone: userData.telefono,
    email: userData.email,
    address: userData.direccion || 'Dirección no especificada',
    district: userData.distrito || 'Lima',
    verified: userData.verificado_reniec,
    memberSince: userData.created_at,
    reportsCount: 12, // TODO: Get from actual reports
    helpedCitizens: 8, // TODO: Calculate from actual data
    trustScore: 95, // TODO: Calculate from actual data
    level: 3, // TODO: Calculate from actual data
    points: 1250, // TODO: Get from actual points
    emergencyContacts: userData.contactos_emergencia ? 
      (Array.isArray(userData.contactos_emergencia) ? userData.contactos_emergencia : []) :
      [
        { name: 'Contacto de Emergencia 1', phone: '+51 987 111 222', relationship: 'Familiar' },
        { name: 'Contacto de Emergencia 2', phone: '+51 987 333 444', relationship: 'Amigo' }
      ]
  } : {
    id: '12345',
    name: 'Ana María García Rodríguez',
    dni: '12345678',
    phone: '+51 987 654 321',
    email: 'ana.garcia@example.com',
    address: 'Av. Universitaria 1245, San Martín de Porres, Lima',
    district: 'San Martín de Porres',
    verified: true,
    memberSince: '2024-01-15',
    reportsCount: 12,
    helpedCitizens: 8,
    trustScore: 95,
    level: 3,
    points: 1250,
    emergencyContacts: [
      { name: 'Carlos García (Esposo)', phone: '+51 987 111 222', relationship: 'Esposo' },
      { name: 'María Rodríguez (Madre)', phone: '+51 987 333 444', relationship: 'Madre' },
      { name: 'Luis García (Hermano)', phone: '+51 987 555 666', relationship: 'Hermano' }
    ]
  };

  const [settings, setSettings] = useState({
    notifications: true,
    locationSharing: true,
    anonymousReports: false,
    emergencyAutoCall: true,
    dataSharing: false,
    incidentAlerts: true,
    communityUpdates: true,
    nightMode: false,
    soundAlerts: true,
    vibrationAlerts: true
  });

  const [stats] = useState({
    totalReports: profile.reportsCount || 12,
    verifiedReports: 10,
    helpedCitizens: profile.helpedCitizens || 8,
    communityPoints: profile.points || 1250,
    safetyScore: profile.trustScore || 95,
    daysActive: 45
  });

  const handleSettingChange = (setting: keyof typeof settings) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };

  const handleEmergencyVerification = () => {
    alert('✅ Verificación RENIEC completada exitosamente');
    setShowDNIVerification(false);
  };

  const handleDeviceRemoteLock = () => {
    alert('📱 Configuración de bloqueo remoto activada. Tu dispositivo podrá ser bloqueado en caso de robo.');
  };

  const getTrustLevel = (score: number) => {
    if (score >= 90) return { label: 'Excelente', color: 'bg-green-500', textColor: 'text-green-600' };
    if (score >= 75) return { label: 'Bueno', color: 'bg-blue-500', textColor: 'text-blue-600' };
    if (score >= 60) return { label: 'Regular', color: 'bg-yellow-500', textColor: 'text-yellow-600' };
    return { label: 'Bajo', color: 'bg-red-500', textColor: 'text-red-600' };
  };

  const trustLevel = getTrustLevel(profile.trustScore);

  return (
    <div className="p-4 pb-20 bg-background">
      {/* Header Minimalista */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl">Mi Perfil</h2>
          <p className="text-muted-foreground">Configuración y datos personales</p>
        </div>
        {onNavigate && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span>Inicio</span>
          </Button>
        )}
      </div>

      {/* Alerta de modo emergencia */}
      {isEmergencyMode && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Modo Emergencia Activo:</strong> Algunas configuraciones están bloqueadas por seguridad.
          </AlertDescription>
        </Alert>
      )}

      {/* Profile Card Principal */}
      <Card className="mb-6 bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <Avatar className="w-16 h-16">
              <AvatarFallback className="text-lg bg-primary text-primary-foreground">
                {(profile.name || 'U U').split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg">{profile.name}</h3>
                {profile.verified && (
                  <Badge variant="default" className="bg-green-500 text-white">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Verificado
                  </Badge>
                )}
              </div>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                <span>Nivel {profile.level}</span>
                <span>•</span>
                <span>{profile.points} puntos</span>
                <span>•</span>
                <span className={`font-medium ${trustLevel.textColor}`}>
                  Confianza: {trustLevel.label}
                </span>
              </div>
              
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-3 h-3" />
                <span>{profile.district}, Lima</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estadísticas Rápidas */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Award className="w-4 h-4" />
            Actividad Ciudadana
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">{stats.totalReports}</div>
              <div className="text-xs text-muted-foreground">Reportes</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{stats.helpedCitizens}</div>
              <div className="text-xs text-muted-foreground">Ayudados</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{stats.safetyScore}%</div>
              <div className="text-xs text-muted-foreground">Confianza</div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Miembro desde {new Date(profile.memberSince).toLocaleDateString('es-PE')} 
              • {stats.daysActive} días activo
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Información Personal */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <User className="w-4 h-4" />
              Información Personal
            </CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowEditProfile(true)}
              disabled={isEmergencyMode}
            >
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground">DNI</Label>
              <p className="text-sm font-medium">{profile.dni}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Teléfono</Label>
              <p className="text-sm font-medium">{profile.phone}</p>
            </div>
          </div>
          
          <div>
            <Label className="text-xs text-muted-foreground">Email</Label>
            <p className="text-sm font-medium">{profile.email}</p>
          </div>
          
          <div>
            <Label className="text-xs text-muted-foreground">Dirección</Label>
            <p className="text-sm font-medium">{profile.address}</p>
          </div>

          {!profile.verified && (
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full border-orange-500 text-orange-600 hover:bg-orange-50"
              onClick={() => setShowDNIVerification(true)}
            >
              <AlertCircle className="w-4 h-4 mr-2" />
              Verificar con RENIEC
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Contactos de Emergencia */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Contactos de Emergencia
            </CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowEmergencyContacts(true)}
              disabled={isEmergencyMode}
            >
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {profile.emergencyContacts.slice(0, 2).map((contact: any, index: number) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <p className="text-sm font-medium">{contact.name}</p>
                  <p className="text-xs text-muted-foreground">{contact.phone}</p>
                </div>
                <Badge variant="secondary" className="text-xs">
                  {contact.relationship}
                </Badge>
              </div>
            ))}
          </div>
          
          {profile.emergencyContacts.length > 2 && (
            <p className="text-xs text-muted-foreground mt-2 text-center">
              +{profile.emergencyContacts.length - 2} contactos más
            </p>
          )}
        </CardContent>
      </Card>

      {/* Configuración de Notificaciones */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Notificaciones
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Alertas de Incidentes</p>
              <p className="text-xs text-muted-foreground">Incidentes cerca de tu ubicación</p>
            </div>
            <Switch 
              checked={settings.incidentAlerts}
              onCheckedChange={() => handleSettingChange('incidentAlerts')}
              disabled={isEmergencyMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Actualizaciones Comunitarias</p>
              <p className="text-xs text-muted-foreground">Noticias y actualizaciones locales</p>
            </div>
            <Switch 
              checked={settings.communityUpdates}
              onCheckedChange={() => handleSettingChange('communityUpdates')}
              disabled={isEmergencyMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Sonido de Alertas</p>
              <p className="text-xs text-muted-foreground">Reproducir sonido en emergencias</p>
            </div>
            <Switch 
              checked={settings.soundAlerts}
              onCheckedChange={() => handleSettingChange('soundAlerts')}
              disabled={isEmergencyMode}
            />
          </div>
        </CardContent>
      </Card>

      {/* Configuración de Privacidad */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Privacidad y Seguridad
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Compartir Ubicación</p>
              <p className="text-xs text-muted-foreground">Permite enviar ubicación en emergencias</p>
            </div>
            <Switch 
              checked={settings.locationSharing}
              onCheckedChange={() => handleSettingChange('locationSharing')}
              disabled={isEmergencyMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Reportes Anónimos</p>
              <p className="text-xs text-muted-foreground">Hacer denuncias sin identificarte</p>
            </div>
            <Switch 
              checked={settings.anonymousReports}
              onCheckedChange={() => handleSettingChange('anonymousReports')}
              disabled={isEmergencyMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Llamada Automática PNP</p>
              <p className="text-xs text-muted-foreground">Llamar automáticamente en emergencias críticas</p>
            </div>
            <Switch 
              checked={settings.emergencyAutoCall}
              onCheckedChange={() => handleSettingChange('emergencyAutoCall')}
              disabled={isEmergencyMode}
            />
          </div>
        </CardContent>
      </Card>

      {/* Opciones de Seguridad */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Lock className="w-4 h-4" />
            Seguridad del Dispositivo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full justify-start"
            onClick={handleDeviceRemoteLock}
            disabled={isEmergencyMode}
          >
            <Smartphone className="w-4 h-4 mr-2" />
            Configurar Bloqueo Remoto
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full justify-start"
            onClick={() => setShowSecuritySettings(true)}
            disabled={isEmergencyMode}
          >
            <Lock className="w-4 h-4 mr-2" />
            Cambiar PIN de Seguridad
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full justify-start"
            disabled={isEmergencyMode}
          >
            <Camera className="w-4 h-4 mr-2" />
            Configurar Foto de Emergencia
          </Button>
        </CardContent>
      </Card>

      {/* Opciones Adicionales */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Más Opciones
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" size="sm" className="w-full justify-start">
            <History className="w-4 h-4 mr-2" />
            Historial de Actividad
          </Button>
          
          <Button variant="outline" size="sm" className="w-full justify-start">
            <HelpCircle className="w-4 h-4 mr-2" />
            Ayuda y Soporte
          </Button>
          
          <Button variant="outline" size="sm" className="w-full justify-start">
            <FileText className="w-4 h-4 mr-2" />
            Términos y Privacidad
          </Button>
        </CardContent>
      </Card>

      {/* Logout */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <Button 
            variant="destructive" 
            size="sm" 
            className="w-full"
            onClick={onLogout}
            disabled={isEmergencyMode}
          >
            <LogOut className="w-4 h-4 mr-2" />
            {isEmergencyMode ? 'Cerrar Sesión (Bloqueado)' : 'Cerrar Sesión'}
          </Button>
          
          {isEmergencyMode && (
            <p className="text-xs text-muted-foreground text-center mt-2">
              No puedes cerrar sesión durante una emergencia activa
            </p>
          )}
        </CardContent>
      </Card>

      {/* Modal de Verificación RENIEC */}
      <Dialog open={showDNIVerification} onOpenChange={setShowDNIVerification}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Verificación RENIEC</DialogTitle>
            <DialogDescription>
              Verifica tu identidad con el Registro Nacional de Identificación y Estado Civil del Perú.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Número de DNI</Label>
              <Input placeholder="Ingresa tu DNI (8 dígitos)" maxLength={8} />
            </div>
            <div>
              <Label>Fecha de Nacimiento</Label>
              <Input type="date" />
            </div>
            <div>
              <Label>Número de Teléfono</Label>
              <Input placeholder="+51 987 654 321" />
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="flex items-center gap-2 text-blue-700 text-sm">
                <Shield className="w-4 h-4" />
                <span>Tus datos están protegidos y encriptados</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowDNIVerification(false)}>
                Cancelar
              </Button>
              <Button className="flex-1" onClick={handleEmergencyVerification}>
                Verificar Identidad
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Contactos de Emergencia */}
      <Dialog open={showEmergencyContacts} onOpenChange={setShowEmergencyContacts}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contactos de Emergencia</DialogTitle>
            <DialogDescription>
              Configura hasta 3 contactos que serán notificados automáticamente en caso de emergencia.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {profile.emergencyContacts.map((contact: any, index: number) => (
              <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                <div className="flex-1">
                  <p className="text-sm font-medium">{contact.name}</p>
                  <p className="text-xs text-muted-foreground">{contact.phone}</p>
                </div>
                <Badge variant="secondary">{contact.relationship}</Badge>
                <Button variant="ghost" size="sm">Editar</Button>
              </div>
            ))}
            <Button variant="outline" className="w-full">
              <Phone className="w-4 h-4 mr-2" />
              Agregar Contacto
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="h-4"></div>
    </div>
  );
}