import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, Book, Scale, AlertCircle, Phone, MessageSquare, Clock, ChevronDown, ChevronUp, ArrowLeft, Home } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../ui/collapsible';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'legal_info' | 'procedure' | 'emergency' | 'general';
}

interface LegalAIScreenProps {
  userData?: any;
  onNavigate: (screen: string) => void;
}

export function LegalAIScreen({ userData, onNavigate }: LegalAIScreenProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '¡Hola! Soy Justiciero, tu asistente legal inteligente. Estoy aquí para ayudarte con consultas legales basadas en la Constitución del Perú y el Código Penal. ¿En qué puedo asistirte hoy?',
      timestamp: new Date(),
      type: 'general'
    }
  ]);
  
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const legalSuggestions = [
    { text: "¿Qué debo hacer si fui víctima de robo?", type: 'procedure' },
    { text: "¿Cuáles son mis derechos constitucionales?", type: 'legal_info' },
    { text: "¿Cómo denunciar acoso sexual?", type: 'procedure' },
    { text: "¿Qué es la legítima defensa?", type: 'legal_info' },
    { text: "¿Cuándo puedo llamar al 105?", type: 'emergency' },
    { text: "¿Qué documentos necesito para una denuncia?", type: 'procedure' }
  ];

  const legalKnowledge = {
    robo: {
      definition: "El robo está tipificado en el artículo 188° del Código Penal peruano como apoderarse ilegítimamente de un bien mueble total o parcialmente ajeno, para aprovecharse de él, sustrayéndolo del lugar en que se encuentra, empleando violencia contra la persona o amenazándola con un peligro inminente para su vida o integridad física.",
      procedure: "1. Denuncia inmediata ante la PNP o Fiscalía\n2. Solicitar certificado médico si hay lesiones\n3. Recopilar evidencias (fotos, testigos)\n4. Seguimiento del caso con el fiscal asignado",
      penalty: "Pena privativa de libertad no menor de tres ni mayor de ocho años."
    },
    acoso: {
      definition: "El acoso sexual está regulado en la Ley N° 27942 y consiste en una conducta física o verbal de naturaleza sexual, indeseada o rechazada por la persona contra la que se dirige.",
      procedure: "1. Documentar los hechos (fechas, lugares, testigos)\n2. Denuncia ante el Ministerio de Trabajo o PNP\n3. En centros laborales, seguir protocolos internos\n4. Solicitar medidas de protección",
      penalty: "Multa y/o inhabilitación según el ámbito donde ocurra."
    },
    emergencia: {
      definition: "Una emergencia es una situación que pone en riesgo inmediato la vida, integridad física o patrimonio de las personas.",
      contacts: "105 - PNP, 116 - Bomberos, 117 - SAMU, 1818 - Serenazgo",
      when: "Cuando existe peligro inmediato, delito en flagrancia, o necesidad de auxilio urgente."
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);
    setShowSuggestions(false);

    // Simular respuesta del asistente
    setTimeout(() => {
      const response = generateLegalResponse(inputMessage);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        type: response.type
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateLegalResponse = (question: string): { content: string; type: 'legal_info' | 'procedure' | 'emergency' | 'general' } => {
    const lowerQuestion = question.toLowerCase();

    if (lowerQuestion.includes('robo') || lowerQuestion.includes('robaron') || lowerQuestion.includes('asalto')) {
      return {
        content: `**Información Legal sobre Robo:**\n\n📖 **Definición Legal:**\n${legalKnowledge.robo.definition}\n\n📋 **Procedimiento a seguir:**\n${legalKnowledge.robo.procedure}\n\n⚖️ **Sanción:**\n${legalKnowledge.robo.penalty}\n\n🚨 **Recomendación:** Si acabas de ser víctima, llama inmediatamente al 105 y activa el botón de emergencia en JUSTIC.IA.`,
        type: 'procedure'
      };
    }

    if (lowerQuestion.includes('acoso') || lowerQuestion.includes('hostigamiento')) {
      return {
        content: `**Información Legal sobre Acoso Sexual:**\n\n📖 **Definición Legal:**\n${legalKnowledge.acoso.definition}\n\n📋 **Procedimiento a seguir:**\n${legalKnowledge.acoso.procedure}\n\n⚖️ **Sanción:**\n${legalKnowledge.acoso.penalty}\n\n💡 **Tip:** Guarda todas las evidencias (mensajes, emails, testigos) y no dudes en denunciar.`,
        type: 'procedure'
      };
    }

    if (lowerQuestion.includes('emergencia') || lowerQuestion.includes('105') || lowerQuestion.includes('llamar')) {
      return {
        content: `**Información sobre Emergencias:**\n\n📞 **Números de Emergencia:**\n${legalKnowledge.emergencia.contacts}\n\n🚨 **¿Cuándo llamar?**\n${legalKnowledge.emergencia.when}\n\n⚡ **En JUSTIC.IA:**\nPuedes usar el botón rojo de EMERGENCIA para activar automáticamente los protocolos de auxilio y notificar a tus contactos.`,
        type: 'emergency'
      };
    }

    if (lowerQuestion.includes('constitucional') || lowerQuestion.includes('derechos') || lowerQuestion.includes('derecho')) {
      return {
        content: `**Derechos Constitucionales Fundamentales:**\n\n🏛️ **Principales derechos (Constitución de 1993):**\n\n• **Art. 2°:** Derecho a la vida, integridad, libertad, seguridad personal\n• **Art. 2.24°:** Derecho a la libertad y seguridad personales\n• **Art. 139°:** Principios de la administración de justicia\n• **Art. 2.7°:** Derecho al honor, buena reputación, intimidad\n\n⚖️ **¿Vulneraron tus derechos?**\nPuedes presentar acción de amparo ante el Poder Judicial.\n\n💼 **Defensa Pública:**\nSi no puedes costear un abogado, el Estado debe proporcionarte uno gratuitamente.`,
        type: 'legal_info'
      };
    }

    if (lowerQuestion.includes('denuncia') || lowerQuestion.includes('denunciar') || lowerQuestion.includes('documentos')) {
      return {
        content: `**Documentos para realizar una denuncia:**\n\n📄 **Documentos básicos requeridos:**\n\n• DNI original y copia\n• Declaración detallada de los hechos\n• Evidencias disponibles (fotos, videos, audios)\n• Certificado médico (si hay lesiones)\n• Lista de testigos con sus datos\n\n📍 **¿Dónde denunciar?**\n• Comisarías PNP (24 horas)\n• Fiscalías Penales\n• Plataforma digital del Ministerio Público\n\n⏰ **Tiempo límite:**\nLa mayoría de delitos prescriben, ¡no demores en denunciar!\n\n💡 **En JUSTIC.IA:**\nPuedes generar un pre-reporte que te ayudará a organizar toda la información antes de ir a denunciar.`,
        type: 'procedure'
      };
    }

    if (lowerQuestion.includes('legítima defensa') || lowerQuestion.includes('defensa') || lowerQuestion.includes('defenderse')) {
      return {
        content: `**Legítima Defensa (Art. 20° Código Penal):**\n\n⚖️ **Definición:**\nActuar en defensa de bienes jurídicos propios o de terceros, siempre que concurran los requisitos establecidos por ley.\n\n📋 **Requisitos:**\n1. **Agresión ilegítima** actual o inminente\n2. **Necesidad racional** del medio empleado\n3. **Falta de provocación** suficiente de quien se defiende\n\n⚠️ **Importante:**\nLa defensa debe ser **proporcional** al ataque. No es defensa legítima si hay exceso o venganza.\n\n🏛️ **Ejemplo legal:**\nSi alguien te amenaza con un cuchillo, puedes defenderte, pero no puedes usar fuerza excesiva cuando el agresor ya no representa peligro.`,
        type: 'legal_info'
      };
    }

    // Respuesta general para otras consultas
    return {
      content: `Entiendo tu consulta. Como asistente legal especializado en el sistema peruano, puedo ayudarte con:\n\n🔹 **Procedimientos legales** (denuncias, trámites)\n🔹 **Derechos constitucionales** y garantías\n🔹 **Información sobre delitos** del Código Penal\n🔹 **Pasos a seguir** en casos específicos\n🔹 **Números de emergencia** y cuándo usarlos\n\n¿Podrías ser más específico sobre tu consulta legal? Por ejemplo:\n• "¿Qué hacer si me robaron?"\n• "¿Cuáles son mis derechos si me detiene la policía?"\n• "¿Cómo denunciar violencia doméstica?"\n\n💡 **Recuerda:** Esta es información general. Para casos complejos, consulta con un abogado especializado.`,
      type: 'general'
    };
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
    setShowSuggestions(false);
  };

  const getMessageTypeIcon = (type?: string) => {
    switch (type) {
      case 'legal_info':
        return <Scale className="w-4 h-4 text-blue-600" />;
      case 'procedure':
        return <Book className="w-4 h-4 text-green-600" />;
      case 'emergency':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Bot className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header Minimalista */}
      <div className="p-4 bg-white border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg">Justiciero IA</h2>
                <p className="text-sm text-muted-foreground">Asistente Legal</p>
              </div>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">Inicio</span>
          </Button>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              message.role === 'user' 
                ? 'bg-blue-600' 
                : 'bg-purple-600'
            }`}>
              {message.role === 'user' ? (
                <User className="w-4 h-4 text-white" />
              ) : (
                <Bot className="w-4 h-4 text-white" />
              )}
            </div>
            
            <div className={`max-w-[80%] ${message.role === 'user' ? 'text-right' : 'text-left'}`}>
              <Card className={`${
                message.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white border-gray-200'
              }`}>
                <CardContent className="p-3">
                  {message.role === 'assistant' && message.type && (
                    <div className="flex items-center gap-2 mb-2">
                      {getMessageTypeIcon(message.type)}
                      <Badge variant="outline" className="text-xs">
                        {message.type === 'legal_info' && 'Información Legal'}
                        {message.type === 'procedure' && 'Procedimiento'}
                        {message.type === 'emergency' && 'Emergencia'}
                        {message.type === 'general' && 'Consulta General'}
                      </Badge>
                    </div>
                  )}
                  
                  <div className="text-sm whitespace-pre-line">
                    {message.content}
                  </div>
                  
                  <div className={`text-xs mt-2 ${
                    message.role === 'user' ? 'text-blue-100' : 'text-muted-foreground'
                  }`}>
                    {message.timestamp.toLocaleTimeString('es-PE', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <Card className="bg-white border-gray-200">
              <CardContent className="p-3">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <span className="text-sm text-muted-foreground ml-2">Justiciero está escribiendo...</span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Elemento invisible para scroll automático */}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestions */}
      {showSuggestions && (
        <div className="p-4 border-t bg-gray-50">
          <Collapsible>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="w-full justify-between mb-3">
                <span className="text-sm">Preguntas frecuentes</span>
                <ChevronDown className="w-4 h-4" />
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="grid grid-cols-1 gap-2">
                {legalSuggestions.map((suggestion, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="text-left justify-start h-auto p-3 whitespace-normal"
                    onClick={() => handleSuggestionClick(suggestion.text)}
                  >
                    <div className="flex items-start gap-2">
                      {getMessageTypeIcon(suggestion.type)}
                      <span className="text-sm">{suggestion.text}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      )}

      {/* Input Area */}
      <div className="p-4 border-t bg-white">
        <div className="flex gap-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Escribe tu consulta legal aquí..."
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1"
            disabled={isTyping}
          />
          <Button 
            onClick={handleSendMessage} 
            disabled={!inputMessage.trim() || isTyping}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        
        <p className="text-xs text-muted-foreground mt-2 text-center">
          Consultas basadas en la Constitución y Código Penal del Perú
        </p>
      </div>
    </div>
  );
}