import React, { useState } from 'react';
import { Award, Gift, Star, Trophy, Phone, Coffee, Ticket, Crown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';

interface Reward {
  id: string;
  title: string;
  description: string;
  points: number;
  category: 'mobile' | 'food' | 'entertainment' | 'services';
  available: boolean;
  icon: any;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  points: number;
  unlocked: boolean;
  icon: any;
}

interface RewardsScreenProps {
  userData?: any;
}

export function RewardsScreen({ userData }: RewardsScreenProps) {
  const [userPoints] = useState(1250);
  const [currentLevel] = useState(3);
  const [nextLevelPoints] = useState(1500);
  
  const [rewards] = useState<Reward[]>([
    {
      id: '1',
      title: 'Recarga Movistar',
      description: '10 soles de recarga móvil',
      points: 500,
      category: 'mobile',
      available: true,
      icon: Phone
    },
    {
      id: '2',
      title: 'Café Gratis',
      description: 'Café en Juan Valdez',
      points: 300,
      category: 'food',
      available: true,
      icon: Coffee
    },
    {
      id: '3',
      title: 'Entrada Cineplanet',
      description: 'Entrada 2D cualquier función',
      points: 800,
      category: 'entertainment',
      available: true,
      icon: Ticket
    },
    {
      id: '4',
      title: 'Recarga Claro',
      description: '20 soles de recarga móvil',
      points: 1000,
      category: 'mobile',
      available: true,
      icon: Phone
    }
  ]);

  const [achievements] = useState<Achievement[]>([
    {
      id: '1',
      title: 'Primer Reporte',
      description: 'Realizaste tu primera denuncia',
      points: 100,
      unlocked: true,
      icon: Star
    },
    {
      id: '2',
      title: 'Ciudadano Activo',
      description: 'Ayudaste en 5 incidentes',
      points: 250,
      unlocked: true,
      icon: Award
    },
    {
      id: '3',
      title: 'Héroe Local',
      description: 'Fuiste reconocido por tu comunidad',
      points: 500,
      unlocked: false,
      icon: Trophy
    },
    {
      id: '4',
      title: 'Guardián de la Ciudad',
      description: 'Completaste 20 reportes exitosos',
      points: 1000,
      unlocked: false,
      icon: Crown
    }
  ]);

  const [leaderboard] = useState([
    { name: 'Ana García', points: 2340, rank: 1, isCurrentUser: false },
    { name: 'Carlos Ruiz', points: 1890, rank: 2, isCurrentUser: false },
    { name: 'Tú', points: 1250, rank: 3, isCurrentUser: true },
    { name: 'María López', points: 1180, rank: 4, isCurrentUser: false },
    { name: 'José Torres', points: 950, rank: 5, isCurrentUser: false }
  ]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'mobile': return Phone;
      case 'food': return Coffee;
      case 'entertainment': return Ticket;
      default: return Gift;
    }
  };

  const progressToNextLevel = ((userPoints % 500) / 500) * 100;

  return (
    <div className="p-4 pb-20">
      {/* Header */}
      <div className="text-center mb-6">
        <h2>Sistema de Recompensas</h2>
        <p className="text-muted-foreground">Gana puntos ayudando a tu comunidad</p>
      </div>

      {/* User Stats */}
      <Card className="mb-6 bg-gradient-to-r from-primary to-blue-600 text-primary-foreground">
        <CardContent className="p-6">
          <div className="text-center mb-4">
            <div className="text-3xl mb-2">{userPoints.toLocaleString()}</div>
            <div className="text-sm opacity-90">Puntos Totales</div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Nivel {currentLevel}</span>
              <span>Nivel {currentLevel + 1}</span>
            </div>
            <Progress value={progressToNextLevel} className="bg-primary-foreground/20" />
            <div className="text-center text-xs opacity-75">
              {nextLevelPoints - userPoints} puntos para el siguiente nivel
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-3 text-center">
            <Trophy className="w-6 h-6 text-yellow-500 mx-auto mb-1" />
            <div className="text-sm">Rank #3</div>
            <div className="text-xs text-muted-foreground">Este mes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <Award className="w-6 h-6 text-primary mx-auto mb-1" />
            <div className="text-sm">12</div>
            <div className="text-xs text-muted-foreground">Reportes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <Star className="w-6 h-6 text-orange-500 mx-auto mb-1" />
            <div className="text-sm">4.8</div>
            <div className="text-xs text-muted-foreground">Rating</div>
          </CardContent>
        </Card>
      </div>

      {/* Available Rewards */}
      <div className="mb-6">
        <h3 className="mb-4">Canjear Puntos</h3>
        <div className="space-y-3">
          {rewards.filter(r => r.available).map((reward) => {
            const Icon = reward.icon;
            const canAfford = userPoints >= reward.points;
            
            return (
              <Card key={reward.id} className={`${!canAfford ? 'opacity-50' : 'hover:shadow-md'}`}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6 text-accent-foreground" />
                    </div>
                    <div className="flex-1">
                      <h4>{reward.title}</h4>
                      <p className="text-sm text-muted-foreground">{reward.description}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm">{reward.points} puntos</span>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      disabled={!canAfford}
                      onClick={() => console.log(`Canjeando ${reward.title}`)}
                    >
                      Canjear
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Achievements */}
      <div className="mb-6">
        <h3 className="mb-4">Logros</h3>
        <div className="grid grid-cols-2 gap-3">
          {achievements.map((achievement) => {
            const Icon = achievement.icon;
            
            return (
              <Card key={achievement.id} className={`${achievement.unlocked ? 'bg-accent' : 'opacity-50'}`}>
                <CardContent className="p-3 text-center">
                  <Icon className={`w-8 h-8 mx-auto mb-2 ${achievement.unlocked ? 'text-primary' : 'text-muted-foreground'}`} />
                  <h4 className="text-sm mb-1">{achievement.title}</h4>
                  <p className="text-xs text-muted-foreground mb-2">{achievement.description}</p>
                  {achievement.unlocked && (
                    <Badge variant="secondary" className="text-xs">
                      +{achievement.points} pts
                    </Badge>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Leaderboard */}
      <div>
        <h3 className="mb-4">Ranking Ciudadano</h3>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Top 5 del Mes</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {leaderboard.map((user) => (
              <div 
                key={user.rank} 
                className={`flex items-center gap-3 p-4 border-b last:border-b-0 ${user.isCurrentUser ? 'bg-accent' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                  user.rank === 1 ? 'bg-yellow-100 text-yellow-600' :
                  user.rank === 2 ? 'bg-gray-100 text-gray-600' :
                  user.rank === 3 ? 'bg-orange-100 text-orange-600' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {user.rank}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className={user.isCurrentUser ? 'font-medium' : ''}>{user.name}</span>
                    {user.isCurrentUser && <Badge variant="outline" className="text-xs">Tú</Badge>}
                  </div>
                  <div className="text-sm text-muted-foreground">{user.points.toLocaleString()} puntos</div>
                </div>
                {user.rank <= 3 && (
                  <Trophy className={`w-5 h-5 ${
                    user.rank === 1 ? 'text-yellow-500' :
                    user.rank === 2 ? 'text-gray-400' :
                    'text-orange-500'
                  }`} />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}