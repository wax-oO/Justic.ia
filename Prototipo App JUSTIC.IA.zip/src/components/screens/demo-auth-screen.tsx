import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Alert, AlertDescription } from '../ui/alert';
import { Shield, AlertTriangle, Users, PhoneCall } from 'lucide-react';
import { Usuario } from '../../lib/database.types';

interface DemoAuthScreenProps {
  onAuthenticated: (user: Usuario) => void;
  onEmergencyAccess: () => void;
  supabaseConnected: boolean;
}

export function DemoAuthScreen({ onAuthenticated, onEmergencyAccess, supabaseConnected }: DemoAuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('demo@justic.ia');
  const [password, setPassword] = useState('123456');
  const [nombre, setNombre] = useState('Usuario');
  const [apellidos, setApellidos] = useState('Demo');
  const [dni, setDni] = useState('12345678');
  const [telefono, setTelefono] = useState('987654321');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simular delay de autenticación
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Crear usuario demo
    const demoUser: Usuario = {
      id: 'demo-user-' + Date.now(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      dni: dni,
      nombre: nombre,
      apellidos: apellidos,
      email: email,
      telefono: telefono,
      fecha_nacimiento: '1990-01-01',
      direccion: 'Lima, Perú',
      distrito: 'Miraflores',
      provincia: 'Lima',
      departamento: 'Lima',
      verificado_reniec: false,
      verificado_email: true,
      verificado_telefono: false,
      avatar_url: null,
      es_emergencia: false,
      estado: 'activo',
      ultima_actividad: new Date().toISOString(),
      configuracion_privacidad: null,
      contactos_emergencia: [
        { nombre: 'María González', telefono: '987123456', relacion: 'Familiar' },
        { nombre: 'Carlos Pérez', telefono: '976543210', relacion: 'Amigo' }
      ],
      auth_user_id: 'demo-auth-' + Date.now()
    };

    setLoading(false);
    onAuthenticated(demoUser);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo y Header */}
        <div className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 bg-primary rounded-full flex items-center justify-center">
            <Shield className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold">JUSTIC.IA</h1>
          <p className="text-muted-foreground">Justicia Inteligente Asistida</p>
          <p className="text-sm text-muted-foreground">Seguridad ciudadana con IA para Perú</p>
        </div>

        {/* Estado de conexión */}
        <Alert className={supabaseConnected ? "border-green-200 bg-green-50" : "border-orange-200 bg-orange-50"}>
          <AlertTriangle className={`h-4 w-4 ${supabaseConnected ? 'text-green-600' : 'text-orange-600'}`} />
          <AlertDescription className={supabaseConnected ? 'text-green-800' : 'text-orange-800'}>
            {supabaseConnected ? 
              '✅ Conectado a Supabase - Funcionalidad completa' : 
              '⚠️ Modo Demo - Usando datos simulados'}
          </AlertDescription>
        </Alert>

        {/* Formulario de Autenticación */}
        <Card>
          <CardHeader>
            <CardTitle>{isLogin ? 'Iniciar Sesión' : 'Registro'}</CardTitle>
            <CardDescription>
              {isLogin ? 
                'Accede a tu cuenta de JUSTIC.IA' : 
                'Crea tu cuenta para reportar incidentes'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="nombre">Nombre</Label>
                      <Input
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="apellidos">Apellidos</Label>
                      <Input
                        id="apellidos"
                        value={apellidos}
                        onChange={(e) => setApellidos(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="dni">DNI</Label>
                    <Input
                      id="dni"
                      value={dni}
                      onChange={(e) => setDni(e.target.value)}
                      maxLength={8}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="telefono">Teléfono</Label>
                    <Input
                      id="telefono"
                      value={telefono}
                      onChange={(e) => setTelefono(e.target.value)}
                      maxLength={9}
                      required
                    />
                  </div>
                </>
              )}

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Procesando...' : (isLogin ? 'Iniciar Sesión' : 'Registrarse')}
              </Button>
            </form>

            <div className="mt-4 text-center">
              <Button 
                variant="link" 
                onClick={() => setIsLogin(!isLogin)}
                className="text-sm"
              >
                {isLogin ? 
                  '¿No tienes cuenta? Regístrate' : 
                  '¿Ya tienes cuenta? Inicia sesión'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Acceso de Emergencia */}
        <Card className="border-red-200">
          <CardHeader className="pb-4">
            <CardTitle className="text-red-600 flex items-center gap-2">
              <PhoneCall className="w-5 h-5" />
              Acceso de Emergencia
            </CardTitle>
            <CardDescription>
              Acceso inmediato sin registro para situaciones críticas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={onEmergencyAccess}
              variant="destructive" 
              className="w-full"
            >
              🚨 Activar Modo Emergencia
            </Button>
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Solo usar en caso de peligro inmediato
            </p>
          </CardContent>
        </Card>

        {/* Información adicional */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              Red ciudadana
            </span>
            <span>•</span>
            <span>IA Legal</span>
            <span>•</span>
            <span>24/7</span>
          </div>
          
          <p className="text-xs text-muted-foreground">
            JUSTIC.IA es una plataforma de seguridad ciudadana<br/>
            basada en inteligencia artificial para Perú
          </p>
        </div>
      </div>
    </div>
  );
}