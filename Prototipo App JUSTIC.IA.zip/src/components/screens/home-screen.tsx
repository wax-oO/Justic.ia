import React, { useState } from 'react';
import { AlertTriangle, Shield, Users, Phone, MapPin, Wifi, WifiOff, Bell, Plus } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Alert, AlertDescription } from '../ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '../ui/dialog';
import { Usuario } from '../../lib/database.types';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
  userData?: Usuario | null;
  isEmergencyMode?: boolean;
}

export function HomeScreen({ onNavigate, userData, isEmergencyMode }: HomeScreenProps) {
  const [isPanicPressed, setIsPanicPressed] = useState(false);
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);

  const handlePanicPress = () => {
    setIsPanicPressed(true);
    setShowEmergencyDialog(true);
    // Simular activación de protocolo de emergencia
    setTimeout(() => {
      setIsPanicPressed(false);
    }, 3000);
  };

  return (
    <div className="p-4 pb-20">
      {/* Header con información del usuario */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Wifi className="h-4 w-4 text-green-500" />
          <span className="text-sm text-muted-foreground">En línea</span>
        </div>
        <div className="relative">
          <Bell className="h-6 w-6 text-gray-600" />
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
            <span className="text-white text-xs">3</span>
          </div>
        </div>
      </div>

      {/* Saludo personalizado */}
      {userData && (
        <div className="mb-6">
          <h2 className="text-xl">Hola, {userData.nombre?.split(' ')[0] || userData.nombre || 'Usuario'}</h2>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <MapPin className="h-3 w-3" />
            <span>{userData.direccion || userData.distrito || 'Lima, Perú'}</span>
          </div>
        </div>
      )}

      {/* Alerta de modo emergencia */}
      {isEmergencyMode && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Modo Emergencia Activado</strong> - Las autoridades han sido notificadas
          </AlertDescription>
        </Alert>
      )}

      {/* Botón de pánico prominente */}
      <Card 
        className="mb-6 bg-red-500 text-white border-0 shadow-lg transition-all duration-300"
        style={{
          animation: 'emergency-full-pulse 3s ease-in-out infinite'
        }}
      >
        <CardContent className="p-6">
          <Dialog open={showEmergencyDialog} onOpenChange={setShowEmergencyDialog}>
            <DialogTrigger asChild>
              <Button
                onClick={handlePanicPress}
                className="w-full h-24 bg-red-500 hover:bg-red-600 text-white border-0 flex-col gap-2 shadow-none transition-all duration-300 hover:scale-105"
              >
                <Shield className="w-8 h-8 text-white" />
                <div className="text-xl font-bold">EMERGENCIA</div>
                <div className="text-sm font-normal opacity-90">Presiona para activar</div>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="text-red-600">🚨 Protocolo de Emergencia Activado</DialogTitle>
                <DialogDescription>
                  El sistema ha activado automáticamente el protocolo de emergencia y ha enviado notificaciones.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <p>Se han enviado alertas a:</p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    Contactos de emergencia notificados
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    Red ciudadana activada en un radio de 500m
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    Ubicación enviada a PNP
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                    Dispositivo bloqueado remotamente
                  </li>
                </ul>
                <Button onClick={() => setShowEmergencyDialog(false)} className="w-full">
                  Entendido
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Acceso Rápido */}
      <div className="mb-6">
        <h3 className="text-lg mb-4">Acceso Rápido</h3>
        <div className="grid grid-cols-2 gap-4">
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('create-report')}>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-3">
                <Shield className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-medium">Reportar Incidente</h4>
              <p className="text-xs text-muted-foreground">Crear nuevo reporte</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('legal-ai')}>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-3">
                <Users className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-medium">Ayuda Legal IA</h4>
              <p className="text-xs text-muted-foreground">Consulta con Justiciero</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('reports')}>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 rounded-full bg-gray-100 text-gray-600 flex items-center justify-center mx-auto mb-3">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-medium">Mis Reportes</h4>
              <p className="text-xs text-muted-foreground">Ver historial</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('map')}>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-3">
                <MapPin className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-medium">Mapa Seguridad</h4>
              <p className="text-xs text-muted-foreground">Zonas peligrosas</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Alertas Comunitarias */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg">Alertas Comunitarias</h3>
          <span className="text-xs text-muted-foreground">Actualizado: {new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
        
        <div className="space-y-3">
          {/* Alerta de Robo */}
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-red-600">ROBO</span>
                    <span className="text-xs text-muted-foreground">Hace 15 min</span>
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Av. Javier Prado Este 1234</span>
                  </div>
                  <p className="text-sm text-gray-700">
                    Robo de celular reportado cerca del centro comercial. Sospechoso huyó...
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Alerta de Asalto */}
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-orange-600">ASALTO</span>
                    <span className="text-xs text-muted-foreground">Hace 32 min</span>
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Jr. Las Flores 890</span>
                  </div>
                  <p className="text-sm text-gray-700">
                    Intento de asalto en paradero. Víctima logró escapar...
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Nivel de Seguridad */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center">
              <Shield className="w-3 h-3 text-blue-600" />
            </div>
            <h4 className="font-medium">Nivel de Seguridad</h4>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            {userData?.direccion?.split(',')[1]?.trim() || userData?.distrito || 'San Isidro'}, Lima
          </p>
          
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="text-2xl font-bold text-orange-600">75</div>
              <div className="text-lg text-muted-foreground">/100</div>
            </div>
            <span className="text-sm font-medium text-orange-600 bg-orange-100 px-2 py-1 rounded">
              MODERADO
            </span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
            <div className="bg-orange-500 h-2 rounded-full" style={{ width: '75%' }}></div>
          </div>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full text-blue-600 border-blue-600 hover:bg-blue-50"
            onClick={() => onNavigate('map')}
          >
            Ver Detalles
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}