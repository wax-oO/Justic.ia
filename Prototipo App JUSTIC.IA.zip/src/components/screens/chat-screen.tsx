import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Camera, Mic, MapPin, FileText } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent } from '../ui/card';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';

interface ChatMessage {
  id: string;
  type: 'bot' | 'user';
  content: string;
  timestamp: Date;
  attachments?: string[];
}

interface ChatScreenProps {
  onNavigate: (screen: string) => void;
  userData?: any;
}

export function ChatScreen({ onNavigate, userData }: ChatScreenProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'bot',
      content: `¡Hola${userData ? `, ${userData.name.split(' ')[0]}` : ''}! Soy Justiciero, tu asistente legal inteligente. Estoy aquí para ayudarte a crear una denuncia legal válida. ¿Qué tipo de incidente necesitas reportar?`,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const denunciaSteps = [
    {
      question: "¿Qué tipo de incidente ocurrió?",
      options: ["Robo", "Acoso", "Agresión", "Extorsión", "Otro"]
    },
    {
      question: "¿Cuándo ocurrió el incidente?",
      options: ["Hace menos de 1 hora", "Hace 1-6 horas", "Hace 6-24 horas", "Hace más de 1 día"]
    },
    {
      question: "¿Dónde ocurrió el incidente?",
      options: ["En la calle", "En transporte público", "En mi casa", "En mi trabajo", "Otro lugar"]
    },
    {
      question: "¿Hubo testigos presentes?",
      options: ["Sí, varios testigos", "Sí, pocos testigos", "No hubo testigos", "No estoy seguro"]
    },
    {
      question: "¿Tienes evidencia del incidente?",
      options: ["Sí, fotos/videos", "Sí, documentos", "Sí, testigos", "No tengo evidencia"]
    }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const simulateBotResponse = (userMessage: string) => {
    setIsTyping(true);
    
    setTimeout(() => {
      let botResponse = "";
      
      if (currentStep < denunciaSteps.length) {
        if (currentStep === denunciaSteps.length - 1) {
          botResponse = "Perfecto. He recopilado toda la información necesaria. Ahora voy a generar tu denuncia legal con un código único. ¿Deseas proceder de forma anónima o identificada?";
        } else {
          botResponse = denunciaSteps[currentStep + 1]?.question || "Procesando tu denuncia...";
        }
        setCurrentStep(prev => prev + 1);
      } else {
        botResponse = "Excelente. Tu denuncia ha sido procesada y se ha generado el ticket legal JA-2024-001234. Te llegará un PDF con el código QR a tu correo. ¿Necesitas ayuda adicional?";
      }

      const newBotMessage: ChatMessage = {
        id: Date.now().toString(),
        type: 'bot',
        content: botResponse,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, newBotMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    simulateBotResponse(inputText);
    setInputText('');
  };

  const handleQuickResponse = (response: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: response,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    simulateBotResponse(response);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center gap-3">
        <Avatar>
          <AvatarFallback className="bg-primary-foreground text-primary">
            <Bot className="w-5 h-5" />
          </AvatarFallback>
        </Avatar>
        <div>
          <h2>Justiciero AI</h2>
          <p className="text-xs opacity-90">Asistente Legal Inteligente</p>
        </div>
        <Badge variant="secondary" className="ml-auto">En línea</Badge>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-32">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <Avatar>
              <AvatarFallback className={message.type === 'bot' ? 'bg-primary text-primary-foreground' : 'bg-muted'}>
                {message.type === 'bot' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </AvatarFallback>
            </Avatar>
            <Card className={`max-w-[80%] ${message.type === 'user' ? 'bg-primary text-primary-foreground' : ''}`}>
              <CardContent className="p-3">
                <p className="text-sm">{message.content}</p>
                <p className={`text-xs mt-1 ${message.type === 'user' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </CardContent>
            </Card>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3">
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground">
                <Bot className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <Card>
              <CardContent className="p-3">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Quick Response Options */}
        {currentStep < denunciaSteps.length && denunciaSteps[currentStep] && (
          <div className="space-y-2">
            <p className="text-sm">Respuestas rápidas:</p>
            <div className="flex flex-wrap gap-2">
              {denunciaSteps[currentStep].options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickResponse(option)}
                  className="text-xs"
                >
                  {option}
                </Button>
              ))}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="fixed bottom-16 left-1/2 transform -translate-x-1/2 w-full max-w-sm bg-background border-t p-4">
        <div className="flex gap-2 mb-2">
          <Button variant="outline" size="sm">
            <Camera className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm">
            <Mic className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm">
            <MapPin className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => onNavigate('reports')}>
            <FileText className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex gap-2">
          <Input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Describe el incidente..."
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1"
          />
          <Button onClick={handleSendMessage} size="sm">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}