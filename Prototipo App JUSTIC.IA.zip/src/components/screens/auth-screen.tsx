import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent } from '../ui/card';
import { Eye, EyeOff, Shield, AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '../ui/dialog';

interface AuthScreenProps {
  onAuthenticated: (userData: any) => void;
  onEmergencyAccess: () => void;
}

export function AuthScreen({ onAuthenticated, onEmergencyAccess }: AuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [credentials, setCredentials] = useState({
    emailOrDni: '',
    password: '',
    pin: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showPinLogin, setShowPinLogin] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simular autenticación
    setTimeout(() => {
      const userData = {
        id: '12345678',
        name: 'María González',
        email: credentials.emailOrDni.includes('@') ? credentials.emailOrDni : 'maria.gonzalez@ejemplo.com',
        dni: '12345678',
        phone: '+51 987 654 321',
        address: 'San Isidro, Lima',
        verified: true,
        emergencyContacts: [
          { name: 'Juan González', phone: '+51 987 123 456', relation: 'Hermano' }
        ]
      };
      
      onAuthenticated(userData);
      setIsLoading(false);
    }, 1500);
  };

  const handlePinLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (credentials.pin.length === 6) {
      setIsLoading(true);
      
      setTimeout(() => {
        const userData = {
          id: '12345678',
          name: 'María González',
          email: 'maria.gonzalez@ejemplo.com',
          dni: '12345678',
          phone: '+51 987 654 321',
          address: 'San Isidro, Lima',
          verified: true,
          emergencyContacts: [
            { name: 'Juan González', phone: '+51 987 123 456', relation: 'Hermano' }
          ]
        };
        
        onAuthenticated(userData);
        setIsLoading(false);
      }, 1000);
    }
  };

  const handleEmergencyAccess = () => {
    onEmergencyAccess();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm space-y-8">
        {/* Logo y título */}
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-primary rounded-2xl mx-auto flex items-center justify-center">
            <span className="text-white font-bold text-lg">J.IA</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">JUSTIC.IA</h1>
            <p className="text-muted-foreground mt-1">Justicia inteligente al alcance de todos</p>
          </div>
        </div>

        {/* Formulario de autenticación */}
        {!showPinLogin ? (
          <Card>
            <CardContent className="p-6 space-y-4">
              <form onSubmit={handleAuth} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="emailOrDni">Email o DNI</Label>
                  <div className="relative">
                    <Input
                      id="emailOrDni"
                      type="text"
                      placeholder="usuario@ejemplo.com"
                      value={credentials.emailOrDni}
                      onChange={(e) => setCredentials({ ...credentials, emailOrDni: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={credentials.password}
                      onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-auto p-1"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="text-right">
                  <button
                    type="button"
                    className="text-sm text-primary hover:underline"
                    onClick={() => {/* Implementar recuperación de contraseña */}}
                  >
                    ¿Olvidaste tu contraseña?
                  </button>
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? 'Iniciando Sesión...' : 'Iniciar Sesión'}
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full mx-auto flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold">Acceso con PIN</h3>
                <p className="text-sm text-muted-foreground">Ingresa tu PIN de 6 dígitos</p>
              </div>

              <form onSubmit={handlePinLogin} className="space-y-4">
                <div className="space-y-2">
                  <Input
                    type="password"
                    placeholder="••••••"
                    maxLength={6}
                    value={credentials.pin}
                    onChange={(e) => setCredentials({ ...credentials, pin: e.target.value.replace(/\D/g, '') })}
                    className="text-center text-2xl tracking-wider"
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading || credentials.pin.length !== 6}
                >
                  {isLoading ? 'Verificando...' : 'Acceder'}
                </Button>

                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => setShowPinLogin(false)}
                >
                  Volver al inicio de sesión
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Botón de acceso de emergencia */}
        <Dialog>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              className="w-full border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
            >
              <AlertTriangle className="w-4 h-4 mr-2" />
              Acceso de Emergencia
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Acceso de Emergencia</DialogTitle>
              <DialogDescription>
                Este acceso está reservado para situaciones de emergencia. Al continuar, se activará el protocolo de emergencia y se notificará a las autoridades.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-destructive/10 p-4 rounded-lg">
                <p className="text-sm text-destructive">
                  <strong>Advertencia:</strong> El acceso de emergencia debe utilizarse únicamente en situaciones de peligro real. El uso indebido puede tener consecuencias legales.
                </p>
              </div>
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => {}}
                >
                  Cancelar
                </Button>
                <Button 
                  variant="destructive" 
                  className="flex-1"
                  onClick={handleEmergencyAccess}
                >
                  Confirmar Emergencia
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Acceso con PIN */}
        {!showPinLogin && (
          <div className="text-center space-y-4">
            <p className="text-sm text-muted-foreground">O inicia sesión con</p>
            
            <Button
              variant="outline"
              className="w-full"
              onClick={() => setShowPinLogin(true)}
            >
              <div className="flex flex-col items-center space-y-1">
                <div className="w-8 h-8 bg-primary text-white rounded flex items-center justify-center text-xs font-bold">
                  123
                </div>
                <span className="text-xs">PIN</span>
              </div>
            </Button>
          </div>
        )}

        {/* Toggle entre login y registro */}
        <div className="text-center">
          <Button
            variant="ghost"
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm"
          >
            {isLogin ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Inicia sesión'}
          </Button>
        </div>
      </div>
    </div>
  );
}