import React, { useState } from 'react';
import { Camera, MapPin, Clock, FileText, Send, AlertTriangle, CheckCircle, Phone, Shield, Users, ArrowLeft, Home } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Checkbox } from '../ui/checkbox';

interface CreateReportScreenProps {
  userData?: any;
  onNavigate: (screen: string) => void;
  onReportCreated?: (report: any) => void;
}

interface ReportForm {
  type: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  location: string;
  description: string;
  datetime: string;
  witnesses: string;
  evidence: string[];
  anonymous: boolean;
  notifyContacts: boolean;
  callPolice: boolean;
}

export function CreateReportScreen({ userData, onNavigate, onReportCreated }: CreateReportScreenProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [showSuccess, setShowSuccess] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  
  const [form, setForm] = useState<ReportForm>({
    type: '',
    urgency: 'medium',
    location: '',
    description: '',
    datetime: new Date().toISOString().slice(0, 16),
    witnesses: '',
    evidence: [],
    anonymous: false,
    notifyContacts: true,
    callPolice: false
  });

  const incidentTypes = [
    { value: 'robo', label: 'Robo', icon: AlertTriangle, color: 'text-red-600', urgency: 'high' },
    { value: 'asalto', label: 'Asalto', icon: AlertTriangle, color: 'text-red-600', urgency: 'critical' },
    { value: 'acoso', label: 'Acoso Sexual', icon: Users, color: 'text-orange-600', urgency: 'medium' },
    { value: 'agresion', label: 'Agresión Física', icon: AlertTriangle, color: 'text-red-600', urgency: 'high' },
    { value: 'extorsion', label: 'Extorsión', icon: Shield, color: 'text-purple-600', urgency: 'high' },
    { value: 'vandalismo', label: 'Vandalismo', icon: AlertTriangle, color: 'text-yellow-600', urgency: 'low' },
    { value: 'otro', label: 'Otro Delito', icon: FileText, color: 'text-gray-600', urgency: 'medium' }
  ];

  const urgencyLevels = [
    { value: 'low', label: 'Baja', color: 'bg-green-100 text-green-800', description: 'Sin peligro inmediato' },
    { value: 'medium', label: 'Media', color: 'bg-yellow-100 text-yellow-800', description: 'Requiere atención' },
    { value: 'high', label: 'Alta', color: 'bg-orange-100 text-orange-800', description: 'Situación seria' },
    { value: 'critical', label: 'Crítica', color: 'bg-red-100 text-red-800', description: 'Peligro inmediato' }
  ];

  const handleIncidentTypeSelect = (type: string) => {
    const incident = incidentTypes.find(i => i.value === type);
    setForm(prev => ({
      ...prev,
      type,
      urgency: incident?.urgency as any || 'medium',
      callPolice: incident?.urgency === 'critical' || incident?.urgency === 'high'
    }));
  };

  const handleLocationDetect = () => {
    // Simular detección de ubicación
    setForm(prev => ({
      ...prev,
      location: 'Av. Javier Prado Este 1245, San Isidro, Lima'
    }));
  };

  const handleEvidenceAdd = (type: string) => {
    // Simular agregar evidencia
    const evidenceId = `${type}_${Date.now()}`;
    setForm(prev => ({
      ...prev,
      evidence: [...prev.evidence, evidenceId]
    }));
  };

  const handleSubmitReport = () => {
    // Generar código único de denuncia
    const code = `JA-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 999999)).padStart(6, '0')}`;
    setGeneratedCode(code);

    // Simular envío del reporte
    const newReport = {
      id: Date.now().toString(),
      code,
      type: incidentTypes.find(i => i.value === form.type)?.label || form.type,
      status: form.urgency === 'critical' ? 'in_progress' : 'pending',
      date: new Date().toISOString().split('T')[0],
      location: form.location,
      description: form.description,
      evidence: form.evidence,
      urgency: form.urgency,
      anonymous: form.anonymous
    };

    // Simular diferentes acciones según urgencia
    if (form.callPolice || form.urgency === 'critical') {
      setTimeout(() => {
        alert('🚨 PNP ha sido notificada automáticamente - Línea 105');
      }, 1000);
    }

    if (form.notifyContacts && !form.anonymous) {
      setTimeout(() => {
        alert('📱 Contactos de emergencia notificados');
      }, 1500);
    }

    setShowSuccess(true);
    onReportCreated?.(newReport);
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg mb-4">Tipo de Incidente</h3>
        <div className="grid grid-cols-1 gap-3">
          {incidentTypes.map((incident) => {
            const Icon = incident.icon;
            return (
              <Card 
                key={incident.value}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  form.type === incident.value 
                    ? 'border-primary bg-primary/5' 
                    : 'hover:border-gray-300'
                }`}
                onClick={() => handleIncidentTypeSelect(incident.value)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <Icon className={`w-6 h-6 ${incident.color}`} />
                    <div className="flex-1">
                      <h4 className="font-medium">{incident.label}</h4>
                      {form.type === incident.value && (
                        <Badge className={urgencyLevels.find(u => u.value === incident.urgency)?.color}>
                          Urgencia: {urgencyLevels.find(u => u.value === incident.urgency)?.label}
                        </Badge>
                      )}
                    </div>
                    {form.type === incident.value && (
                      <CheckCircle className="w-5 h-5 text-primary" />
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div>
        <Label>Nivel de Urgencia</Label>
        <Select value={form.urgency} onValueChange={(value: any) => setForm(prev => ({ ...prev, urgency: value }))}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {urgencyLevels.map((level) => (
              <SelectItem key={level.value} value={level.value}>
                <div className="flex items-center gap-2">
                  <Badge className={level.color}>{level.label}</Badge>
                  <span className="text-sm text-muted-foreground">{level.description}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div>
        <Label>Ubicación del Incidente</Label>
        <div className="flex gap-2">
          <Input
            value={form.location}
            onChange={(e) => setForm(prev => ({ ...prev, location: e.target.value }))}
            placeholder="Dirección completa o referencia"
            className="flex-1"
          />
          <Button
            type="button"
            variant="outline"
            onClick={handleLocationDetect}
            className="flex-shrink-0"
          >
            <MapPin className="w-4 h-4 mr-1" />
            Detectar
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Sé lo más específico posible (calle, número, referencias)
        </p>
      </div>

      <div>
        <Label>Fecha y Hora del Incidente</Label>
        <Input
          type="datetime-local"
          value={form.datetime}
          onChange={(e) => setForm(prev => ({ ...prev, datetime: e.target.value }))}
          max={new Date().toISOString().slice(0, 16)}
        />
      </div>

      <div>
        <Label>Descripción Detallada</Label>
        <Textarea
          value={form.description}
          onChange={(e) => setForm(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Describe exactamente qué ocurrió, cómo ocurrió, quiénes estuvieron involucrados..."
          rows={6}
          className="resize-none"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Incluye todos los detalles que recuerdes: apariencia física, vestimenta, vehículos, etc.
        </p>
      </div>

      <div>
        <Label>Testigos (Opcional)</Label>
        <Textarea
          value={form.witnesses}
          onChange={(e) => setForm(prev => ({ ...prev, witnesses: e.target.value }))}
          placeholder="Nombres, números de teléfono o descripciones de testigos..."
          rows={3}
        />
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg mb-4">Evidencias</h3>
        <div className="grid grid-cols-2 gap-4">
          <Button
            type="button"
            variant="outline"
            className="h-24 flex-col gap-2"
            onClick={() => handleEvidenceAdd('photo')}
          >
            <Camera className="w-8 h-8 text-muted-foreground" />
            <span className="text-sm">Tomar Foto</span>
          </Button>
          
          <Button
            type="button"
            variant="outline"
            className="h-24 flex-col gap-2"
            onClick={() => handleEvidenceAdd('video')}
          >
            <FileText className="w-8 h-8 text-muted-foreground" />
            <span className="text-sm">Grabar Video</span>
          </Button>
        </div>
        
        {form.evidence.length > 0 && (
          <div className="mt-4">
            <p className="text-sm font-medium mb-2">Evidencias agregadas:</p>
            <div className="space-y-2">
              {form.evidence.map((evidence, index) => (
                <div key={index} className="flex items-center gap-2 p-2 bg-muted rounded">
                  <FileText className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{evidence}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <h3 className="text-lg">Configuración del Reporte</h3>
        
        <div className="flex items-center space-x-2">
          <Checkbox
            id="anonymous"
            checked={form.anonymous}
            onCheckedChange={(checked) => setForm(prev => ({ ...prev, anonymous: !!checked }))}
          />
          <Label htmlFor="anonymous" className="text-sm">
            Hacer denuncia anónima
          </Label>
        </div>

        {!form.anonymous && (
          <div className="flex items-center space-x-2">
            <Checkbox
              id="notify-contacts"
              checked={form.notifyContacts}
              onCheckedChange={(checked) => setForm(prev => ({ ...prev, notifyContacts: !!checked }))}
            />
            <Label htmlFor="notify-contacts" className="text-sm">
              Notificar a mis contactos de emergencia
            </Label>
          </div>
        )}

        <div className="flex items-center space-x-2">
          <Checkbox
            id="call-police"
            checked={form.callPolice}
            onCheckedChange={(checked) => setForm(prev => ({ ...prev, callPolice: !!checked }))}
          />
          <Label htmlFor="call-police" className="text-sm">
            Notificar automáticamente a la PNP
          </Label>
        </div>

        {(form.urgency === 'critical' || form.urgency === 'high') && (
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>Urgencia Alta:</strong> Se recomienda notificar inmediatamente a las autoridades.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );

  const renderStepNavigation = () => (
    <div className="flex justify-between pt-4 border-t">
      <Button
        variant="outline"
        onClick={() => setCurrentStep(currentStep - 1)}
        disabled={currentStep === 1}
      >
        Anterior
      </Button>
      
      {currentStep < 3 ? (
        <Button
          onClick={() => setCurrentStep(currentStep + 1)}
          disabled={
            (currentStep === 1 && !form.type) ||
            (currentStep === 2 && (!form.location || !form.description))
          }
        >
          Siguiente
        </Button>
      ) : (
        <Button
          onClick={handleSubmitReport}
          className="bg-red-600 hover:bg-red-700 text-white"
          disabled={!form.type || !form.location || !form.description}
        >
          <Send className="w-4 h-4 mr-2" />
          Enviar Denuncia
        </Button>
      )}
    </div>
  );

  if (showSuccess) {
    return (
      <div className="p-4 pb-20">
        {/* Header de éxito */}
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h2 className="text-lg">Denuncia Enviada</h2>
          <div className="w-8"></div>
        </div>

        <Card className="text-center">
          <CardContent className="p-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            
            <h3 className="text-xl mb-2">¡Denuncia Enviada!</h3>
            <p className="text-muted-foreground mb-6">
              Tu denuncia ha sido registrada exitosamente
            </p>
            
            <Card className="bg-blue-50 border-blue-200 mb-6">
              <CardContent className="p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <span className="font-medium">Código de Denuncia:</span>
                </div>
                <div className="text-2xl font-bold text-blue-600 mb-2">
                  {generatedCode}
                </div>
                <p className="text-sm text-blue-700">
                  Guarda este código para hacer seguimiento
                </p>
              </CardContent>
            </Card>

            <div className="space-y-3 text-left mb-6">
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Denuncia registrada en el sistema</span>
              </div>
              
              {form.callPolice && (
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>PNP notificada automáticamente</span>
                </div>
              )}
              
              {form.notifyContacts && !form.anonymous && (
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Contactos de emergencia notificados</span>
                </div>
              )}
              
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Certificado digital generado</span>
              </div>
            </div>

            <div className="space-y-2">
              <Button 
                onClick={() => onNavigate('reports')} 
                className="w-full"
              >
                Ver Mis Denuncias
              </Button>
              
              <Button 
                variant="outline" 
                onClick={() => onNavigate('home')} 
                className="w-full"
              >
                <Home className="w-4 h-4 mr-2" />
                Volver al Inicio
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header Minimalista */}
      <div className="p-4 bg-white border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('home')}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg">Reportar Incidente</h2>
                <p className="text-sm text-muted-foreground">Crear nueva denuncia</p>
              </div>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">Inicio</span>
          </Button>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="p-4 border-b bg-gray-50">
        <div className="flex items-center justify-between mb-2">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step <= currentStep 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-gray-200 text-gray-500'
              }`}>
                {step}
              </div>
              {step < 3 && (
                <div className={`w-16 h-0.5 mx-2 ${
                  step < currentStep ? 'bg-primary' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>
        
        <div className="text-sm text-muted-foreground text-center">
          {currentStep === 1 && 'Tipo e Información Básica'}
          {currentStep === 2 && 'Ubicación y Descripción'}
          {currentStep === 3 && 'Evidencias y Configuración'}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {currentStep === 1 && renderStep1()}
        {currentStep === 2 && renderStep2()}
        {currentStep === 3 && renderStep3()}
      </div>

      {/* Navigation */}
      <div className="p-4 border-t bg-white">
        {renderStepNavigation()}
      </div>
    </div>
  );
}