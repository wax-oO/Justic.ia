import React, { useState, useEffect } from 'react';
import { MapPin, AlertTriangle, Shield, Users, Navigation, Filter, Search, Clock, Phone, Home, ArrowLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

interface IncidentMarker {
  id: string;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: string;
  coordinates: { lat: number; lng: number };
  time: string;
  timestamp: Date;
  description: string;
  verified: boolean;
  citizenReports: number;
  policeResponse: boolean;
}

interface MapScreenProps {
  userData?: any;
  onNavigate?: (screen: string) => void;
}

export function MapScreen({ userData, onNavigate }: MapScreenProps) {
  const [selectedIncident, setSelectedIncident] = useState<IncidentMarker | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterSeverity, setFilterSeverity] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [userLocation, setUserLocation] = useState({ lat: -12.0464, lng: -77.0428 });
  const [currentTime, setCurrentTime] = useState(new Date());

  const [incidents, setIncidents] = useState<IncidentMarker[]>([
    {
      id: '1',
      type: 'Robo',
      severity: 'critical',
      location: 'Av. Javier Prado Este 1234',
      coordinates: { lat: -12.0464, lng: -77.0428 },
      time: 'Hace 15 min',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      description: 'Robo de celular a mano armada. Sospechoso huyó hacia Jr. Las Flores.',
      verified: true,
      citizenReports: 3,
      policeResponse: true
    },
    {
      id: '2',
      type: 'Asalto',
      severity: 'high',
      location: 'Jr. Las Flores 890',
      coordinates: { lat: -12.0469, lng: -77.0308 },
      time: 'Hace 32 min',
      timestamp: new Date(Date.now() - 32 * 60 * 1000),
      description: 'Intento de asalto en paradero. Víctima logró escapar.',
      verified: true,
      citizenReports: 2,
      policeResponse: false
    },
    {
      id: '3',
      type: 'Acoso',
      severity: 'medium',
      location: 'Estación Metropolitano - Línea Azul',
      coordinates: { lat: -12.0458, lng: -77.0351 },
      time: 'Hace 1 hora',
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      description: 'Acoso verbal en transporte público reportado por múltiples usuarios.',
      verified: false,
      citizenReports: 5,
      policeResponse: false
    },
    {
      id: '4',
      type: 'Zona Segura',
      severity: 'low',
      location: 'Comisaría San Isidro',
      coordinates: { lat: -12.0958, lng: -77.0351 },
      time: 'Permanente',
      timestamp: new Date(),
      description: 'Zona con vigilancia policial 24/7. Punto de referencia seguro.',
      verified: true,
      citizenReports: 0,
      policeResponse: true
    },
    {
      id: '5',
      type: 'Extorsión',
      severity: 'high',
      location: 'Mercado Central - Puesto 45',
      coordinates: { lat: -12.0408, lng: -77.0285 },
      time: 'Hace 2 horas',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      description: 'Comerciante reporta extorsión por parte de grupo organizado.',
      verified: true,
      citizenReports: 1,
      policeResponse: true
    },
    {
      id: '6',
      type: 'Agresión',
      severity: 'critical',
      location: 'Parque Central - Zona Norte',
      coordinates: { lat: -12.0008, lng: -76.9972 },
      time: 'Hace 8 min',
      timestamp: new Date(Date.now() - 8 * 60 * 1000),
      description: 'Agresión física en progreso. PNP y ambulancia en camino.',
      verified: true,
      citizenReports: 4,
      policeResponse: true
    }
  ]);

  // Actualizar tiempo cada minuto
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Filtrar incidentes
  const filteredIncidents = incidents.filter(incident => {
    const matchesSearch = incident.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         incident.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || incident.type === filterType;
    const matchesSeverity = filterSeverity === 'all' || incident.severity === filterSeverity;
    
    return matchesSearch && matchesType && matchesSeverity;
  });

  const getSeverityInfo = (severity: string) => {
    switch (severity) {
      case 'critical':
        return { 
          color: 'bg-red-600', 
          textColor: 'text-red-600', 
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200',
          label: 'CRÍTICO',
          pulseColor: 'animate-pulse bg-red-500'
        };
      case 'high':
        return { 
          color: 'bg-orange-500', 
          textColor: 'text-orange-600', 
          bgColor: 'bg-orange-50',
          borderColor: 'border-orange-200',
          label: 'ALTO',
          pulseColor: 'animate-pulse bg-orange-500'
        };
      case 'medium':
        return { 
          color: 'bg-yellow-500', 
          textColor: 'text-yellow-600', 
          bgColor: 'bg-yellow-50',
          borderColor: 'border-yellow-200',
          label: 'MEDIO',
          pulseColor: 'bg-yellow-500'
        };
      case 'low':
        return { 
          color: 'bg-green-500', 
          textColor: 'text-green-600', 
          bgColor: 'bg-green-50',
          borderColor: 'border-green-200',
          label: 'SEGURO',
          pulseColor: 'bg-green-500'
        };
      default:
        return { 
          color: 'bg-gray-500', 
          textColor: 'text-gray-600', 
          bgColor: 'bg-gray-50',
          borderColor: 'border-gray-200',
          label: 'DESCONOCIDO',
          pulseColor: 'bg-gray-500'
        };
    }
  };

  const getIncidentIcon = (type: string) => {
    switch (type) {
      case 'Zona Segura':
        return Shield;
      case 'Robo':
      case 'Asalto':
      case 'Agresión':
        return AlertTriangle;
      case 'Acoso':
        return Users;
      default:
        return MapPin;
    }
  };

  const getRelativeTime = (timestamp: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - timestamp.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 1) return 'Ahora mismo';
    if (diffMins < 60) return `Hace ${diffMins} min`;
    if (diffHours < 24) return `Hace ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
    return timestamp.toLocaleDateString();
  };

  const handleEmergencyCall = () => {
    // Simular llamada de emergencia
    alert('🚨 Conectando con PNP - Línea de Emergencia 105');
  };

  const centerOnUserLocation = () => {
    // Simular centrar en ubicación del usuario
    setUserLocation({ lat: -12.0464, lng: -77.0428 });
    alert('📍 Centrando mapa en tu ubicación actual');
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header con búsqueda y filtros */}
      <div className="p-4 bg-primary text-primary-foreground">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-xl">Mapa de Seguridad</h2>
            <p className="text-sm opacity-90">
              {filteredIncidents.length} incidentes activos en {userData?.address?.split(',')[1] || 'Lima'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={handleEmergencyCall}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              <Phone className="w-4 h-4 mr-1" />
              105
            </Button>
            {onNavigate && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => onNavigate('home')}
                className="bg-white text-primary hover:bg-gray-100"
              >
                <Home className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
        
        {/* Barra de búsqueda */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar ubicación o tipo de incidente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-white text-foreground"
            />
          </div>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="bg-white text-primary"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>

        {/* Panel de filtros */}
        {showFilters && (
          <div className="mt-3 p-3 bg-white/10 rounded-lg">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs opacity-90 mb-1 block">Tipo de Incidente</label>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="bg-white text-foreground h-8">
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="Robo">Robo</SelectItem>
                    <SelectItem value="Asalto">Asalto</SelectItem>
                    <SelectItem value="Acoso">Acoso</SelectItem>
                    <SelectItem value="Agresión">Agresión</SelectItem>
                    <SelectItem value="Extorsión">Extorsión</SelectItem>
                    <SelectItem value="Zona Segura">Zona Segura</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs opacity-90 mb-1 block">Nivel de Riesgo</label>
                <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                  <SelectTrigger className="bg-white text-foreground h-8">
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="critical">Crítico</SelectItem>
                    <SelectItem value="high">Alto</SelectItem>
                    <SelectItem value="medium">Medio</SelectItem>
                    <SelectItem value="low">Seguro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Contenedor del mapa */}
      <div className="flex-1 relative bg-gradient-to-br from-blue-50 to-green-50 overflow-hidden">
        {/* Fondo del mapa simulado con calles */}
        <div className="absolute inset-0">
          <svg className="w-full h-full opacity-30" viewBox="0 0 400 300">
            {/* Calles principales */}
            <path d="M0,75 L400,75" stroke="#4a5568" strokeWidth="3" />
            <path d="M0,150 L400,150" stroke="#4a5568" strokeWidth="4" />
            <path d="M0,225 L400,225" stroke="#4a5568" strokeWidth="3" />
            <path d="M80,0 L80,300" stroke="#4a5568" strokeWidth="3" />
            <path d="M160,0 L160,300" stroke="#4a5568" strokeWidth="4" />
            <path d="M240,0 L240,300" stroke="#4a5568" strokeWidth="3" />
            <path d="M320,0 L320,300" stroke="#4a5568" strokeWidth="3" />
            
            {/* Calles secundarias */}
            <path d="M0,37.5 L400,37.5" stroke="#718096" strokeWidth="1.5" />
            <path d="M0,112.5 L400,112.5" stroke="#718096" strokeWidth="1.5" />
            <path d="M0,187.5 L400,187.5" stroke="#718096" strokeWidth="1.5" />
            <path d="M0,262.5 L400,262.5" stroke="#718096" strokeWidth="1.5" />
            <path d="M40,0 L40,300" stroke="#718096" strokeWidth="1.5" />
            <path d="M120,0 L120,300" stroke="#718096" strokeWidth="1.5" />
            <path d="M200,0 L200,300" stroke="#718096" strokeWidth="1.5" />
            <path d="M280,0 L280,300" stroke="#718096" strokeWidth="1.5" />
            <path d="M360,0 L360,300" stroke="#718096" strokeWidth="1.5" />
            
            {/* Parques y areas verdes */}
            <circle cx="100" cy="100" r="25" fill="#68d391" opacity="0.3" />
            <circle cx="300" cy="200" r="20" fill="#68d391" opacity="0.3" />
            <rect x="150" y="50" width="40" height="30" fill="#68d391" opacity="0.3" rx="5" />
          </svg>
        </div>

        {/* Mapa de calor de riesgo */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Zona de alto riesgo */}
          <div 
            className="absolute w-32 h-32 bg-red-500 rounded-full opacity-20"
            style={{ left: '15%', top: '20%' }}
          />
          <div 
            className="absolute w-24 h-24 bg-orange-500 rounded-full opacity-15"
            style={{ left: '60%', top: '60%' }}
          />
          <div 
            className="absolute w-20 h-20 bg-yellow-500 rounded-full opacity-10"
            style={{ left: '40%', top: '40%' }}
          />
        </div>

        {/* Marcadores de incidentes */}
        <div className="absolute inset-0">
          {filteredIncidents.map((incident, index) => {
            const severityInfo = getSeverityInfo(incident.severity);
            const Icon = getIncidentIcon(incident.type);
            
            // Posicionar basándose en coordenadas simuladas
            const position = {
              left: `${Math.min(85, Math.max(10, 20 + (index * 15) % 60))}%`,
              top: `${Math.min(85, Math.max(10, 25 + (index * 12) % 50))}%`
            };
            
            return (
              <div
                key={incident.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 hover:scale-125 hover:z-10"
                style={position}
                onClick={() => setSelectedIncident(incident)}
              >
                {/* Círculo de pulso para incidentes críticos/recientes */}
                {(incident.severity === 'critical' || new Date().getTime() - incident.timestamp.getTime() < 30 * 60 * 1000) && (
                  <div className={`absolute inset-0 w-10 h-10 rounded-full ${severityInfo.pulseColor} opacity-50 animate-ping`} />
                )}
                
                {/* Marcador principal */}
                <div className={`relative w-10 h-10 rounded-full ${severityInfo.color} flex items-center justify-center shadow-lg border-2 border-white`}>
                  <Icon className="w-5 h-5 text-white" />
                  
                  {/* Indicador de verificación */}
                  {incident.verified && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border border-white" />
                  )}
                  
                  {/* Indicador de respuesta policial */}
                  {incident.policeResponse && (
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border border-white" />
                  )}
                </div>
                
                {/* Etiqueta del tipo */}
                <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                  <Badge 
                    variant="secondary" 
                    className={`text-xs ${severityInfo.bgColor} ${severityInfo.textColor} ${severityInfo.borderColor} border`}
                  >
                    {incident.type}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>

        {/* Ubicación del usuario */}
        <div 
          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
          style={{ left: '50%', top: '50%' }}
        >
          <div className="relative">
            <div className="w-4 h-4 bg-blue-600 rounded-full animate-pulse" />
            <div className="absolute inset-0 w-4 h-4 bg-blue-400 rounded-full animate-ping" />
          </div>
          <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2">
            <Badge variant="default" className="text-xs bg-blue-600">
              Tu ubicación
            </Badge>
          </div>
        </div>

        {/* Botones de control */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <Button
            size="sm"
            onClick={centerOnUserLocation}
            className="rounded-full w-12 h-12 p-0 bg-blue-600 hover:bg-blue-700"
          >
            <Navigation className="w-5 h-5" />
          </Button>
          <Button
            size="sm"
            onClick={() => setFilterSeverity('critical')}
            className="rounded-full w-12 h-12 p-0 bg-red-600 hover:bg-red-700"
          >
            <AlertTriangle className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Estadísticas rápidas */}
      <div className="p-3 bg-white border-t">
        <div className="flex justify-between items-center mb-2">
          <h4 className="text-sm font-medium">Estado de Seguridad</h4>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>Actualizado: {currentTime.toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-2 text-center">
          <div className="bg-red-50 p-2 rounded">
            <div className="text-lg font-bold text-red-600">
              {incidents.filter(i => i.severity === 'critical').length}
            </div>
            <div className="text-xs text-red-600">Críticos</div>
          </div>
          <div className="bg-orange-50 p-2 rounded">
            <div className="text-lg font-bold text-orange-600">
              {incidents.filter(i => i.severity === 'high').length}
            </div>
            <div className="text-xs text-orange-600">Alto</div>
          </div>
          <div className="bg-green-50 p-2 rounded">
            <div className="text-lg font-bold text-green-600">
              {incidents.filter(i => i.policeResponse).length}
            </div>
            <div className="text-xs text-green-600">PNP Activo</div>
          </div>
          <div className="bg-blue-50 p-2 rounded">
            <div className="text-lg font-bold text-blue-600">245</div>
            <div className="text-xs text-blue-600">Ciudadanos</div>
          </div>
        </div>

        {/* Botón de reportar incidente desde el mapa */}
        {onNavigate && (
          <Button
            onClick={() => onNavigate('create-report')}
            className="w-full mt-3 bg-red-600 hover:bg-red-700"
            size="sm"
          >
            <AlertTriangle className="w-4 h-4 mr-2" />
            Reportar Incidente Aquí
          </Button>
        )}
      </div>

      {/* Modal de detalles del incidente */}
      {selectedIncident && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50" onClick={() => setSelectedIncident(null)}>
          <Card className="w-full rounded-t-xl max-h-96 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <CardTitle className="text-lg">{selectedIncident.type}</CardTitle>
                    {selectedIncident.verified && (
                      <Badge variant="secondary" className="text-xs bg-blue-50 text-blue-600">
                        ✓ Verificado
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {selectedIncident.location}
                  </p>
                </div>
                <Badge className={`${getSeverityInfo(selectedIncident.severity).bgColor} ${getSeverityInfo(selectedIncident.severity).textColor} border-0`}>
                  {getSeverityInfo(selectedIncident.severity).label}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-4">
                <p className="text-sm">{selectedIncident.description}</p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>{getRelativeTime(selectedIncident.timestamp)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>{selectedIncident.citizenReports} reportes</span>
                  </div>
                </div>

                {selectedIncident.policeResponse && (
                  <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 text-green-700">
                      <Shield className="w-4 h-4" />
                      <span className="text-sm font-medium">PNP en respuesta</span>
                    </div>
                    <p className="text-xs text-green-600 mt-1">
                      Las autoridades han sido notificadas y están respondiendo al incidente.
                    </p>
                  </div>
                )}
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Users className="w-4 h-4 mr-1" />
                    Reportar Info
                  </Button>
                  <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                    <Phone className="w-4 h-4 mr-1" />
                    Llamar PNP
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="pb-16"></div>
    </div>
  );
}