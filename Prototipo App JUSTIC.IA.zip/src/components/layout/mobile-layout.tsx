import React from 'react';

interface MobileLayoutProps {
  children: React.ReactNode;
  className?: string;
}

export function MobileLayout({ children, className = "" }: MobileLayoutProps) {
  return (
    <div className={`max-w-sm mx-auto min-h-screen bg-background border-x border-border ${className}`}>
      {children}
    </div>
  );
}