# 🚀 Configuración de Supabase para JUSTIC.IA

Esta guía te ayudará a configurar Supabase como backend para tu aplicación JUSTIC.IA.

## 📋 **REQUISITOS PREVIOS**

- [ ] Cuenta en [Supabase](https://app.supabase.com)
- [ ] Node.js y npm/yarn instalado
- [ ] Código de JUSTIC.IA funcionando localmente

## 🛠️ **PASO 1: Crear Proyecto en Supabase**

### 1.1 Crear Nuevo Proyecto
1. Ve a https://app.supabase.com
2. Haz clic en "New Project"
3. Configura:
   - **Name**: `justic-ia-app`
   - **Database Password**: Una contraseña segura
   - **Region**: Sudamérica (closest to Peru)
4. Haz clic en "Create new project"

### 1.2 Obtener Credenciales
1. Ve a `Settings > API`
2. Copia estos valores:
   - **Project URL**: `https://tu-proyecto.supabase.co`
   - **Anon public key**: `eyJhbGciOiJIUzI1NiIs...`
   - **Service role secret**: `eyJhbGciOiJIUzI1NiIs...` ⚠️ (mantén secreto)

## 🗄️ **PASO 2: Configurar Base de Datos**

### 2.1 Ejecutar Schema SQL
1. Ve a `SQL Editor` en tu dashboard de Supabase
2. Crea una nueva query
3. Copia y pega el contenido completo de `/supabase/schema.sql`
4. Haz clic en "Run" para ejecutar

### 2.2 Verificar Tablas Creadas
Deberías ver estas tablas en `Table Editor`:
- ✅ `usuarios`
- ✅ `reportes`
- ✅ `emergencias`
- ✅ `alertas_proximidad`
- ✅ `recompensas`
- ✅ `consultas_ia`

### 2.3 Configurar RLS (Row Level Security)
El script ya habilitó RLS automáticamente. Verifica en cada tabla que aparezca:
- 🛡️ "RLS enabled" ✅

## 🔑 **PASO 3: Configurar Autenticación**

### 3.1 Habilitar Proveedores de Auth
1. Ve a `Authentication > Settings`
2. En "Auth Providers", habilita:
   - ✅ Email
   - ✅ Google (opcional)
   - ✅ Phone (opcional para SMS)

### 3.2 Configurar URLs de Redirect
En `Authentication > URL Configuration`:
- **Site URL**: `http://localhost:3000` (desarrollo)
- **Redirect URLs**: 
  - `http://localhost:3000`
  - `https://tu-dominio.com` (producción)

### 3.3 Configurar Email Templates
En `Authentication > Email Templates`, personaliza:
- **Confirm signup**: Mensaje de bienvenida a JUSTIC.IA
- **Reset password**: Instrucciones de reset para usuarios

## 🔧 **PASO 4: Configurar Variables de Entorno**

### 4.1 Crear Archivo .env.local
```bash
# En la raíz de tu proyecto
cp env.example .env.local
```

### 4.2 Configurar Variables
Edita `.env.local` con tus valores reales:

```env
# SUPABASE
NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIs...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIs...

# OTROS (agregar gradualmente)
NEXT_PUBLIC_OPENAI_API_KEY=sk-proj-...
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=AIzaSy...
```

## 🧪 **PASO 5: Probar Configuración**

### 5.1 Verificar Conexión
1. Inicia tu aplicación: `npm run dev`
2. Verifica en la consola del navegador:
   - ✅ "Conexión a Supabase exitosa"
   - ❌ Si ves errores, revisa las credenciales

### 5.2 Probar Registro de Usuario
1. Ve a la pantalla de registro
2. Crea un usuario de prueba
3. Verifica en Supabase `Table Editor > usuarios`:
   - Debe aparecer el nuevo usuario
   - Estado: "activo"
   - `auth_user_id` debe estar poblado

### 5.3 Probar Funcionalidades
- ✅ Login/Logout
- ✅ Crear reporte de prueba
- ✅ Consultar asistente IA
- ✅ Ver perfil de usuario

## 🛡️ **PASO 6: Configuración de Seguridad**

### 6.1 Configurar CORS
En `Settings > API`:
- **CORS Origins**: 
  - `http://localhost:3000`
  - `https://tu-dominio.com`

### 6.2 Configurar Rate Limiting
En `Settings > API`:
- **Rate Limiting**: Habilitar
- **Requests per minute**: 100 (ajustar según necesidad)

### 6.3 Revisar Políticas RLS
En `Authentication > Policies`, verifica que estén activas:
- `usuarios`: Usuarios pueden ver/editar su perfil
- `reportes`: Usuarios pueden ver reportes públicos y crear los suyos
- `emergencias`: Usuarios pueden crear emergencias y ver activas
- `recompensas`: Usuarios pueden ver sus puntos
- `consultas_ia`: Usuarios pueden ver su historial

## 📊 **PASO 7: Configurar Funciones Edge (Opcional)**

### 7.1 Para Procesamiento IA Avanzado
```sql
-- Crear función para procesamiento de consultas IA
CREATE OR REPLACE FUNCTION procesar_consulta_ia(
    user_id UUID,
    pregunta TEXT
)
RETURNS TABLE (respuesta TEXT, categoria TEXT)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Lógica de procesamiento
    -- Integración con OpenAI
    -- Retornar respuesta procesada
END;
$$;
```

### 7.2 Para Notificaciones en Tiempo Real
```sql
-- Trigger para notificaciones de emergencia
CREATE OR REPLACE FUNCTION notificar_emergencia()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    -- Enviar notificación en tiempo real
    PERFORM pg_notify('nueva_emergencia', row_to_json(NEW)::text);
    RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_notificar_emergencia
    AFTER INSERT ON emergencias
    FOR EACH ROW
    EXECUTE FUNCTION notificar_emergencia();
```

## 🚀 **PASO 8: Optimización y Monitoreo**

### 8.1 Configurar Índices Adicionales
```sql
-- Para consultas geográficas optimizadas
CREATE INDEX idx_reportes_ubicacion_gist 
ON reportes USING GIST (
    ll_to_earth(ubicacion_lat, ubicacion_lng)
);
```

### 8.2 Configurar Backups
En `Settings > Database`:
- ✅ Habilitar backups automáticos
- Frecuencia: Diaria
- Retención: 7 días (plan gratuito)

### 8.3 Monitoreo
En `Reports`:
- Revisar métricas de uso
- Monitorear consultas lentas
- Verificar uso de storage

## 📱 **PASO 9: Preparar para Producción**

### 9.1 Actualizar URLs
- Cambiar URLs de localhost a tu dominio real
- Actualizar redirects de autenticación
- Configurar certificados SSL

### 9.2 Optimizar Configuración
- Aumentar límites de rate limiting
- Configurar CDN para assets
- Habilitar compresión

### 9.3 Configurar Monitoreo de Errores
- Integrar Sentry o similar
- Configurar alertas de Supabase
- Monitorear métricas de rendimiento

## ❓ **RESOLUCIÓN DE PROBLEMAS**

### Problema: "Failed to fetch"
- ✅ Verificar URLs de Supabase
- ✅ Comprobar CORS configuration
- ✅ Verificar que el proyecto esté activo

### Problema: "Row Level Security"
- ✅ Verificar que RLS esté habilitado
- ✅ Comprobar políticas de seguridad
- ✅ Verificar que el usuario esté autenticado

### Problema: "Invalid JWT"
- ✅ Verificar fechas de expiración
- ✅ Comprobar que las keys sean correctas
- ✅ Refrescar tokens de autenticación

## 📞 **SOPORTE**

- 📚 Documentación: https://supabase.com/docs
- 💬 Discord: https://discord.supabase.com
- 🐛 Issues: https://github.com/supabase/supabase/issues
- 📧 Soporte Enterprise: support@supabase.com

---

## ✅ **CHECKLIST FINAL**

- [ ] Proyecto Supabase creado
- [ ] Schema SQL ejecutado correctamente
- [ ] Tablas y funciones creadas
- [ ] RLS y políticas configuradas
- [ ] Variables de entorno configuradas
- [ ] Autenticación funcionando
- [ ] Pruebas básicas exitosas
- [ ] CORS y seguridad configurados
- [ ] Backups habilitados
- [ ] Monitoreo configurado

¡Tu aplicación JUSTIC.IA está lista para usar Supabase como backend! 🎉