import { supabase, isSupabaseAvailable } from './supabase'
import { InsertReporte, Reporte, InsertEmergencia, Emergencia, InsertRecompensa } from './database.types'

// Tipos para reportes
export interface DatosReporte {
  tipo: 'robo' | 'acoso' | 'agresion' | 'extorsion' | 'otro'
  titulo: string
  descripcion: string
  ubicacion: { lat: number; lng: number }
  direccion?: string
  fechaIncidente: string
  horaIncidente?: string
  evidencias?: any[]
  testigos?: any[]
  agresorDescripcion?: string
  vehiculoDescripcion?: string
  objetosSustraidos?: any[]
  montoAproximado?: number
}

export interface DatosEmergencia {
  tipo: 'panico' | 'medica' | 'violencia' | 'robo_flagrancia' | 'accidente'
  ubicacion: { lat: number; lng: number }
  descripcion?: string
  contactosEmergencia?: string[]
}

// Servicio de Reportes para JUSTIC.IA
export class ReportesService {

  // Crear nuevo reporte
  static async crearReporte(usuarioId: string, datos: DatosReporte): Promise<{
    success: boolean
    reporte?: Reporte
    error?: string
  }> {
    try {
      // Verificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        // En modo demo, simular reporte exitoso
        const reporteDemo: Reporte = {
          id: 'demo-report-' + Date.now(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          usuario_id: usuarioId,
          tipo_incidente: datos.tipo,
          subtipo: null,
          titulo: datos.titulo,
          descripcion: datos.descripcion,
          ubicacion_lat: datos.ubicacion.lat,
          ubicacion_lng: datos.ubicacion.lng,
          direccion_referencial: datos.direccion || null,
          distrito: null,
          provincia: null,
          departamento: null,
          fecha_incidente: datos.fechaIncidente,
          hora_incidente: datos.horaIncidente || null,
          evidencias: datos.evidencias || null,
          testigos: datos.testigos || null,
          agresor_descripcion: datos.agresorDescripcion || null,
          vehiculo_descripcion: datos.vehiculoDescripcion || null,
          objetos_sustraidos: datos.objetosSustraidos || null,
          monto_aproximado: datos.montoAproximado || null,
          codigo_qr: `JUSTIC-DEMO-${Date.now()}`,
          codigo_seguimiento: `REP-DEMO-${Date.now().toString().slice(-8)}`,
          estado: 'pendiente',
          prioridad: ReportesService.calcularPrioridad(datos.tipo),
          visible_publico: true,
          denuncia_pnp: null,
          seguimiento_pnp: null,
          calificacion_usuario: null,
          comentario_usuario: null,
          asignado_a: null,
          resolucion: null,
          fecha_resolucion: null
        };

        console.log('📝 Reporte creado en modo demo:', reporteDemo.codigo_seguimiento);
        return {
          success: true,
          reporte: reporteDemo
        };
      }

      // Generar códigos únicos
      const codigoQR = `JUSTIC-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      const codigoSeguimiento = `REP-${Date.now().toString().slice(-8)}`

      const nuevoReporte: InsertReporte = {
        usuario_id: usuarioId,
        tipo_incidente: datos.tipo,
        titulo: datos.titulo,
        descripcion: datos.descripcion,
        ubicacion_lat: datos.ubicacion.lat,
        ubicacion_lng: datos.ubicacion.lng,
        direccion_referencial: datos.direccion || null,
        fecha_incidente: datos.fechaIncidente,
        hora_incidente: datos.horaIncidente || null,
        evidencias: datos.evidencias || null,
        testigos: datos.testigos || null,
        agresor_descripcion: datos.agresorDescripcion || null,
        vehiculo_descripcion: datos.vehiculoDescripcion || null,
        objetos_sustraidos: datos.objetosSustraidos || null,
        monto_aproximado: datos.montoAproximado || null,
        codigo_qr: codigoQR,
        codigo_seguimiento: codigoSeguimiento,
        estado: 'pendiente',
        prioridad: ReportesService.calcularPrioridad(datos.tipo),
        visible_publico: true
      }

      const { data: reporte, error } = await supabase!
        .from('reportes')
        .insert(nuevoReporte)
        .select()
        .single()

      if (error) {
        throw new Error(error.message)
      }

      // Dar puntos por crear reporte
      await ReportesService.otorgarPuntos(usuarioId, 'reporte', 10, reporte.id)

      // Crear alerta de proximidad si es necesario
      await ReportesService.crearAlertaProximidad(reporte)

      return {
        success: true,
        reporte
      }

    } catch (error) {
      console.error('Error creando reporte:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Obtener reportes del usuario
  static async obtenerReportesUsuario(usuarioId: string): Promise<{
    success: boolean
    reportes?: Reporte[]
    error?: string
  }> {
    try {
      const { data: reportes, error } = await supabase
        .from('reportes')
        .select('*')
        .eq('usuario_id', usuarioId)
        .order('created_at', { ascending: false })

      if (error) {
        throw new Error(error.message)
      }

      return {
        success: true,
        reportes: reportes || []
      }

    } catch (error) {
      console.error('Error obteniendo reportes:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Obtener reportes cercanos para el mapa
  static async obtenerReportesCercanos(
    lat: number, 
    lng: number, 
    radioKm: number = 5
  ): Promise<{
    success: boolean
    reportes?: any[]
    error?: string
  }> {
    try {
      const { data: reportes, error } = await supabase
        .rpc('obtener_reportes_cercanos', {
          lat,
          lng,
          radio_km: radioKm
        })

      if (error) {
        throw new Error(error.message)
      }

      return {
        success: true,
        reportes: reportes || []
      }

    } catch (error) {
      console.error('Error obteniendo reportes cercanos:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Activar emergencia
  static async activarEmergencia(usuarioId: string, datos: DatosEmergencia): Promise<{
    success: boolean
    emergencia?: Emergencia
    error?: string
  }> {
    try {
      const nuevaEmergencia: InsertEmergencia = {
        usuario_id: usuarioId,
        ubicacion_lat: datos.ubicacion.lat,
        ubicacion_lng: datos.ubicacion.lng,
        tipo_emergencia: datos.tipo,
        descripcion: datos.descripcion || null,
        estado: 'activa',
        contactos_notificados: datos.contactosEmergencia || null
      }

      const { data: emergencia, error } = await supabase
        .from('emergencias')
        .insert(nuevaEmergencia)
        .select()
        .single()

      if (error) {
        throw new Error(error.message)
      }

      // Notificar contactos de emergencia
      if (datos.contactosEmergencia?.length) {
        await ReportesService.notificarContactosEmergencia(
          datos.contactosEmergencia,
          datos.ubicacion,
          emergencia.id
        )
      }

      // Crear alerta de emergencia en radio amplio
      await ReportesService.crearAlertaEmergencia(emergencia)

      return {
        success: true,
        emergencia
      }

    } catch (error) {
      console.error('Error activando emergencia:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Calcular prioridad del reporte
  static calcularPrioridad(tipo: string): 'baja' | 'media' | 'alta' | 'critica' {
    switch (tipo) {
      case 'emergencia':
        return 'critica'
      case 'robo':
      case 'agresion':
        return 'alta'
      case 'acoso':
      case 'extorsion':
        return 'media'
      default:
        return 'baja'
    }
  }

  // Crear alerta de proximidad
  static async crearAlertaProximidad(reporte: Reporte): Promise<void> {
    try {
      // Solo crear alertas para incidentes graves
      if (['robo', 'agresion', 'emergencia'].includes(reporte.tipo_incidente)) {
        await supabase
          .from('alertas_proximidad')
          .insert({
            reporte_id: reporte.id,
            ubicacion_lat: reporte.ubicacion_lat,
            ubicacion_lng: reporte.ubicacion_lng,
            radio_metros: 500, // 500 metros de radio
            tipo_alerta: 'incidente',
            mensaje: `Incidente reportado: ${reporte.tipo_incidente} en ${reporte.direccion_referencial || 'la zona'}`,
            activa: true,
            fecha_expiracion: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 horas
          })
      }
    } catch (error) {
      console.error('Error creando alerta de proximidad:', error)
    }
  }

  // Crear alerta de emergencia
  static async crearAlertaEmergencia(emergencia: Emergencia): Promise<void> {
    try {
      await supabase
        .from('alertas_proximidad')
        .insert({
          emergencia_id: emergencia.id,
          ubicacion_lat: emergencia.ubicacion_lat,
          ubicacion_lng: emergencia.ubicacion_lng,
          radio_metros: 1000, // 1km de radio para emergencias
          tipo_alerta: 'emergencia',
          mensaje: `🚨 EMERGENCIA ACTIVA: ${emergencia.tipo_emergencia}`,
          activa: true,
          fecha_expiracion: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // 2 horas
        })
    } catch (error) {
      console.error('Error creando alerta de emergencia:', error)
    }
  }

  // Otorgar puntos de recompensa
  static async otorgarPuntos(
    usuarioId: string,
    tipo: 'reporte' | 'verificacion' | 'testimonio' | 'colaboracion' | 'referido',
    puntos: number,
    reporteId?: string
  ): Promise<void> {
    try {
      const nuevaRecompensa: InsertRecompensa = {
        usuario_id: usuarioId,
        tipo_actividad: tipo,
        puntos,
        descripcion: ReportesService.obtenerDescripcionPuntos(tipo, puntos),
        reporte_id: reporteId || null
      }

      await supabase
        .from('recompensas')
        .insert(nuevaRecompensa)

    } catch (error) {
      console.error('Error otorgando puntos:', error)
    }
  }

  // Obtener descripción de puntos
  static obtenerDescripcionPuntos(tipo: string, puntos: number): string {
    switch (tipo) {
      case 'reporte':
        return `+${puntos} puntos por crear un reporte`
      case 'verificacion':
        return `+${puntos} puntos por verificar información`
      case 'testimonio':
        return `+${puntos} puntos por proporcionar testimonio`
      case 'colaboracion':
        return `+${puntos} puntos por colaborar con la comunidad`
      case 'referido':
        return `+${puntos} puntos por referir a un amigo`
      default:
        return `+${puntos} puntos por actividad cívica`
    }
  }

  // Notificar contactos de emergencia (simulado)
  static async notificarContactosEmergencia(
    contactos: string[],
    ubicacion: { lat: number; lng: number },
    emergenciaId: string
  ): Promise<void> {
    try {
      // TODO: Integrar con Twilio SMS o servicio similar
      console.log('Notificando contactos de emergencia:', {
        contactos,
        ubicacion,
        emergenciaId,
        mensaje: `🚨 EMERGENCIA - Tu contacto activó una alerta de emergencia. Ubicación: ${ubicacion.lat}, ${ubicacion.lng}`
      })
    } catch (error) {
      console.error('Error notificando contactos:', error)
    }
  }

  // Obtener estadísticas del usuario
  static async obtenerEstadisticasUsuario(usuarioId: string): Promise<{
    success: boolean
    estadisticas?: {
      totalReportes: number
      reportesResueltos: number
      puntosTotales: number
      nivelUsuario: string
    }
    error?: string
  }> {
    try {
      const { data: estadisticas, error } = await supabase
        .rpc('obtener_estadisticas_usuario', { user_id: usuarioId })

      if (error) {
        throw new Error(error.message)
      }

      const stats = estadisticas?.[0] || {
        total_reportes: 0,
        reportes_resueltos: 0,
        puntos_totales: 0,
        nivel_usuario: 'Principiante'
      }

      return {
        success: true,
        estadisticas: {
          totalReportes: stats.total_reportes,
          reportesResueltos: stats.reportes_resueltos,
          puntosTotales: stats.puntos_totales,
          nivelUsuario: stats.nivel_usuario
        }
      }

    } catch (error) {
      console.error('Error obteniendo estadísticas:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }
}