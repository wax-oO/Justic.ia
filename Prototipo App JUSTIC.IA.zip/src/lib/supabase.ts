import { createClient } from '@supabase/supabase-js'
import { Database } from './database.types'

// Configuración de Supabase para JUSTIC.IA - Versión mejorada
const getEnvVar = (key: string, fallback: string): string => {
  // En el navegador, usar variables globales si están disponibles
  if (typeof window !== 'undefined') {
    const windowVar = (window as any)[key];
    if (windowVar) return windowVar;
  }
  
  return fallback;
}

// Verificar si tenemos credenciales válidas de Supabase
const hasValidSupabaseCredentials = (): boolean => {
  const url = getEnvVar('NEXT_PUBLIC_SUPABASE_URL', '');
  const key = getEnvVar('NEXT_PUBLIC_SUPABASE_ANON_KEY', '');
  
  return url !== '' && 
         key !== '' && 
         url !== 'https://demo-project.supabase.co' && 
         key !== 'demo-anon-key' &&
         url.includes('supabase.co') &&
         key.startsWith('eyJ');
}

// Singleton para evitar múltiples instancias
let supabaseInstance: any = null;
let supabaseAdminInstance: any = null;

// Solo crear instancias si tenemos credenciales válidas
const createSupabaseInstance = () => {
  if (!hasValidSupabaseCredentials()) {
    console.log('🔧 Supabase no configurado - usando modo demo');
    return null;
  }

  if (supabaseInstance) {
    return supabaseInstance;
  }

  const supabaseUrl = getEnvVar('NEXT_PUBLIC_SUPABASE_URL', '');
  const supabaseAnonKey = getEnvVar('NEXT_PUBLIC_SUPABASE_ANON_KEY', '');

  supabaseInstance = createClient<Database>(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true
    },
    realtime: {
      params: {
        eventsPerSecond: 10
      }
    }
  });

  return supabaseInstance;
}

const createSupabaseAdminInstance = () => {
  if (!hasValidSupabaseCredentials()) {
    return null;
  }

  if (supabaseAdminInstance) {
    return supabaseAdminInstance;
  }

  const supabaseUrl = getEnvVar('NEXT_PUBLIC_SUPABASE_URL', '');
  const serviceKey = getEnvVar('SUPABASE_SERVICE_ROLE_KEY', '');

  if (!serviceKey || serviceKey === 'demo-service-role-key') {
    return null;
  }

  supabaseAdminInstance = createClient<Database>(
    supabaseUrl,
    serviceKey,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    }
  );

  return supabaseAdminInstance;
}

// Exportar instancias (pueden ser null si no hay credenciales)
export const supabase = createSupabaseInstance();
export const supabaseAdmin = createSupabaseAdminInstance();

// Función para verificar conexión
export const verificarConexionSupabase = async (): Promise<boolean> => {
  try {
    // Si no tenemos instancia válida, retornar false inmediatamente
    if (!supabase) {
      console.log('🔧 Supabase no configurado - funcionando en modo demo');
      return false;
    }

    // Intentar una consulta simple
    const { data, error } = await supabase.from('usuarios').select('count').limit(1);
    
    if (error) {
      console.log('❌ Error conectando a Supabase:', error.message);
      return false;
    }

    console.log('✅ Conexión a Supabase exitosa');
    return true;
  } catch (error) {
    console.log('❌ Error conectando a Supabase - usando modo demo');
    return false;
  }
}

// Función helper para verificar si Supabase está disponible
export const isSupabaseAvailable = (): boolean => {
  return supabase !== null && hasValidSupabaseCredentials();
}