import { supabase, isSupabaseAvailable } from './supabase'
import { InsertUsuario, Usuario } from './database.types'

// Tipos para autenticación
export interface CredencialesLogin {
  email: string
  password: string
}

export interface CredencialesRegistro extends CredencialesLogin {
  dni: string
  nombre: string
  apellidos: string
  telefono: string
  fechaNacimiento?: string
  direccion?: string
}

export interface RespuestaAuth {
  success: boolean
  usuario?: Usuario
  error?: string
  requiresVerification?: boolean
}

// Servicio de Autenticación para JUSTIC.IA
export class AuthService {
  
  // Registrar nuevo usuario
  static async registrarUsuario(credenciales: CredencialesRegistro): Promise<RespuestaAuth> {
    try {
      // Verificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        throw new Error('Supabase no está configurado. Usando modo demo.');
      }

      // 1. Crear usuario en Supabase Auth
      const { data: authData, error: authError } = await supabase!.auth.signUp({
        email: credenciales.email,
        password: credenciales.password,
        options: {
          data: {
            nombre: credenciales.nombre,
            apellidos: credenciales.apellidos,
            dni: credenciales.dni,
            telefono: credenciales.telefono
          }
        }
      })

      if (authError) {
        throw new Error(authError.message)
      }

      if (!authData.user) {
        throw new Error('Error creando usuario')
      }

      // 2. Crear perfil en tabla usuarios
      const nuevoUsuario: InsertUsuario = {
        dni: credenciales.dni,
        nombre: credenciales.nombre,
        apellidos: credenciales.apellidos,
        email: credenciales.email,
        telefono: credenciales.telefono,
        fecha_nacimiento: credenciales.fechaNacimiento || null,
        direccion: credenciales.direccion || null,
        auth_user_id: authData.user.id,
        estado: 'activo',
        es_emergencia: false,
        verificado_reniec: false,
        verificado_email: false,
        verificado_telefono: false
      }

      const { data: usuario, error: userError } = await supabase!
        .from('usuarios')
        .insert(nuevoUsuario)
        .select()
        .single()

      if (userError) {
        // Si falla la creación del perfil, eliminar usuario de auth
        await supabase!.auth.admin.deleteUser(authData.user.id)
        throw new Error(userError.message)
      }

      return {
        success: true,
        usuario,
        requiresVerification: !authData.user.email_confirmed_at
      }

    } catch (error) {
      console.error('Error en registro:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Iniciar sesión
  static async iniciarSesion(credenciales: CredencialesLogin): Promise<RespuestaAuth> {
    try {
      // Verificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        throw new Error('Supabase no está configurado. Usando modo demo.');
      }

      const { data: authData, error: authError } = await supabase!.auth.signInWithPassword({
        email: credenciales.email,
        password: credenciales.password
      })

      if (authError) {
        throw new Error(authError.message)
      }

      if (!authData.user) {
        throw new Error('Credenciales inválidas')
      }

      // Obtener datos del usuario desde la tabla usuarios
      const { data: usuario, error: userError } = await supabase!
        .from('usuarios')
        .select('*')
        .eq('auth_user_id', authData.user.id)
        .single()

      if (userError || !usuario) {
        throw new Error('Usuario no encontrado en la base de datos')
      }

      // Actualizar última actividad
      await supabase!
        .from('usuarios')
        .update({ ultima_actividad: new Date().toISOString() })
        .eq('id', usuario.id)

      return {
        success: true,
        usuario
      }

    } catch (error) {
      console.error('Error en login:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Cerrar sesión
  static async cerrarSesion(): Promise<{ success: boolean; error?: string }> {
    try {
      // Verificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        // En modo demo, simplemente retornar éxito
        return { success: true }
      }

      const { error } = await supabase!.auth.signOut()
      
      if (error) {
        throw new Error(error.message)
      }

      return { success: true }

    } catch (error) {
      console.error('Error en logout:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Obtener usuario actual
  static async obtenerUsuarioActual(): Promise<RespuestaAuth> {
    try {
      // Verificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        return { success: false, error: 'Supabase no está configurado' }
      }

      const { data: { user: authUser }, error: authError } = await supabase!.auth.getUser()

      if (authError) {
        throw new Error(authError.message)
      }

      if (!authUser) {
        return { success: false, error: 'No hay usuario autenticado' }
      }

      const { data: usuario, error: userError } = await supabase!
        .from('usuarios')
        .select('*')
        .eq('auth_user_id', authUser.id)
        .single()

      if (userError || !usuario) {
        throw new Error('Usuario no encontrado')
      }

      return {
        success: true,
        usuario
      }

    } catch (error) {
      console.error('Error obteniendo usuario:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Resetear contraseña
  static async resetearPassword(email: string): Promise<{ success: boolean; error?: string }> {
    try {
      // Verificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        throw new Error('Supabase no está configurado')
      }

      const { error } = await supabase!.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`
      })

      if (error) {
        throw new Error(error.message)
      }

      return { success: true }

    } catch (error) {
      console.error('Error reseteando password:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Verificar DNI con RENIEC (simulado por ahora)
  static async verificarDNI(dni: string): Promise<{ 
    success: boolean; 
    datos?: { nombre: string; apellidos: string; fechaNacimiento: string }; 
    error?: string 
  }> {
    try {
      // TODO: Integrar con API real de RENIEC
      // Por ahora simulamos la verificación
      
      if (dni.length !== 8 || !/^\d+$/.test(dni)) {
        throw new Error('DNI debe tener 8 dígitos')
      }

      // Simulación de respuesta RENIEC
      const datosMock = {
        nombre: 'Juan Carlos',
        apellidos: 'Pérez González',
        fechaNacimiento: '1990-01-01'
      }

      return {
        success: true,
        datos: datosMock
      }

    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error verificando DNI'
      }
    }
  }

  // Crear usuario temporal para emergencias
  static crearUsuarioEmergencia(): Usuario {
    return {
      id: 'emergency-' + Date.now(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      dni: 'EMERGENCIA',
      nombre: 'Usuario',
      apellidos: 'Emergencia',
      email: 'emergencia@temp.com',
      telefono: 'N/A',
      fecha_nacimiento: null,
      direccion: 'Ubicación detectada automáticamente',
      distrito: null,
      provincia: null,
      departamento: null,
      verificado_reniec: false,
      verificado_email: false,
      verificado_telefono: false,
      avatar_url: null,
      es_emergencia: true,
      estado: 'activo',
      ultima_actividad: new Date().toISOString(),
      configuracion_privacidad: null,
      contactos_emergencia: [],
      auth_user_id: null
    }
  }
}

// Hook para escuchar cambios de autenticación
export const useAuthListener = (callback: (usuario: Usuario | null) => void) => {
  // Solo configurar listener si Supabase está disponible
  if (!isSupabaseAvailable()) {
    return;
  }

  supabase!.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_IN' && session?.user) {
      const { data: usuario } = await supabase!
        .from('usuarios')
        .select('*')
        .eq('auth_user_id', session.user.id)
        .single()
      
      callback(usuario)
    } else if (event === 'SIGNED_OUT') {
      callback(null)
    }
  })
}