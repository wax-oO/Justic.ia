export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      usuarios: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          dni: string
          nombre: string
          apellidos: string
          email: string
          telefono: string
          fecha_nacimiento: string | null
          direccion: string | null
          distrito: string | null
          provincia: string | null
          departamento: string | null
          verificado_reniec: boolean
          verificado_email: boolean
          verificado_telefono: boolean
          avatar_url: string | null
          es_emergencia: boolean
          estado: 'activo' | 'inactivo' | 'suspendido'
          ultima_actividad: string | null
          configuracion_privacidad: Json | null
          contactos_emergencia: Json | null
          auth_user_id: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          dni: string
          nombre: string
          apellidos: string
          email: string
          telefono: string
          fecha_nacimiento?: string | null
          direccion?: string | null
          distrito?: string | null
          provincia?: string | null
          departamento?: string | null
          verificado_reniec?: boolean
          verificado_email?: boolean
          verificado_telefono?: boolean
          avatar_url?: string | null
          es_emergencia?: boolean
          estado?: 'activo' | 'inactivo' | 'suspendido'
          ultima_actividad?: string | null
          configuracion_privacidad?: Json | null
          contactos_emergencia?: Json | null
          auth_user_id?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          dni?: string
          nombre?: string
          apellidos?: string
          email?: string
          telefono?: string
          fecha_nacimiento?: string | null
          direccion?: string | null
          distrito?: string | null
          provincia?: string | null
          departamento?: string | null
          verificado_reniec?: boolean
          verificado_email?: boolean
          verificado_telefono?: boolean
          avatar_url?: string | null
          es_emergencia?: boolean
          estado?: 'activo' | 'inactivo' | 'suspendido'
          ultima_actividad?: string | null
          configuracion_privacidad?: Json | null
          contactos_emergencia?: Json | null
          auth_user_id?: string | null
        }
      }
      reportes: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          usuario_id: string
          tipo_incidente: 'robo' | 'acoso' | 'agresion' | 'extorsion' | 'emergencia' | 'otro'
          subtipo: string | null
          titulo: string
          descripcion: string
          ubicacion_lat: number
          ubicacion_lng: number
          direccion_referencial: string | null
          distrito: string | null
          provincia: string | null
          departamento: string | null
          fecha_incidente: string
          hora_incidente: string | null
          evidencias: Json | null
          testigos: Json | null
          agresor_descripcion: string | null
          vehiculo_descripcion: string | null
          objetos_sustraidos: Json | null
          monto_aproximado: number | null
          codigo_qr: string
          codigo_seguimiento: string
          estado: 'pendiente' | 'en_proceso' | 'resuelto' | 'cerrado' | 'rechazado'
          prioridad: 'baja' | 'media' | 'alta' | 'critica'
          visible_publico: boolean
          denuncia_pnp: string | null
          seguimiento_pnp: Json | null
          calificacion_usuario: number | null
          comentario_usuario: string | null
          asignado_a: string | null
          resolucion: string | null
          fecha_resolucion: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          usuario_id: string
          tipo_incidente: 'robo' | 'acoso' | 'agresion' | 'extorsion' | 'emergencia' | 'otro'
          subtipo?: string | null
          titulo: string
          descripcion: string
          ubicacion_lat: number
          ubicacion_lng: number
          direccion_referencial?: string | null
          distrito?: string | null
          provincia?: string | null
          departamento?: string | null
          fecha_incidente: string
          hora_incidente?: string | null
          evidencias?: Json | null
          testigos?: Json | null
          agresor_descripcion?: string | null
          vehiculo_descripcion?: string | null
          objetos_sustraidos?: Json | null
          monto_aproximado?: number | null
          codigo_qr: string
          codigo_seguimiento: string
          estado?: 'pendiente' | 'en_proceso' | 'resuelto' | 'cerrado' | 'rechazado'
          prioridad?: 'baja' | 'media' | 'alta' | 'critica'
          visible_publico?: boolean
          denuncia_pnp?: string | null
          seguimiento_pnp?: Json | null
          calificacion_usuario?: number | null
          comentario_usuario?: string | null
          asignado_a?: string | null
          resolucion?: string | null
          fecha_resolucion?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          usuario_id?: string
          tipo_incidente?: 'robo' | 'acoso' | 'agresion' | 'extorsion' | 'emergencia' | 'otro'
          subtipo?: string | null
          titulo?: string
          descripcion?: string
          ubicacion_lat?: number
          ubicacion_lng?: number
          direccion_referencial?: string | null
          distrito?: string | null
          provincia?: string | null
          departamento?: string | null
          fecha_incidente?: string
          hora_incidente?: string | null
          evidencias?: Json | null
          testigos?: Json | null
          agresor_descripcion?: string | null
          vehiculo_descripcion?: string | null
          objetos_sustraidos?: Json | null
          monto_aproximado?: number | null
          codigo_qr?: string
          codigo_seguimiento?: string
          estado?: 'pendiente' | 'en_proceso' | 'resuelto' | 'cerrado' | 'rechazado'
          prioridad?: 'baja' | 'media' | 'alta' | 'critica'
          visible_publico?: boolean
          denuncia_pnp?: string | null
          seguimiento_pnp?: Json | null
          calificacion_usuario?: number | null
          comentario_usuario?: string | null
          asignado_a?: string | null
          resolucion?: string | null
          fecha_resolucion?: string | null
        }
      }
      emergencias: {
        Row: {
          id: string
          created_at: string
          usuario_id: string
          ubicacion_lat: number
          ubicacion_lng: number
          direccion_referencial: string | null
          tipo_emergencia: 'panico' | 'medica' | 'violencia' | 'robo_flagrancia' | 'accidente'
          descripcion: string | null
          estado: 'activa' | 'atendida' | 'cancelada' | 'falsa_alarma'
          tiempo_respuesta: number | null
          contactos_notificados: Json | null
          autoridades_notificadas: Json | null
          resolucion: string | null
          fecha_resolucion: string | null
          calificacion: number | null
        }
        Insert: {
          id?: string
          created_at?: string
          usuario_id: string
          ubicacion_lat: number
          ubicacion_lng: number
          direccion_referencial?: string | null
          tipo_emergencia: 'panico' | 'medica' | 'violencia' | 'robo_flagrancia' | 'accidente'
          descripcion?: string | null
          estado?: 'activa' | 'atendida' | 'cancelada' | 'falsa_alarma'
          tiempo_respuesta?: number | null
          contactos_notificados?: Json | null
          autoridades_notificadas?: Json | null
          resolucion?: string | null
          fecha_resolucion?: string | null
          calificacion?: number | null
        }
        Update: {
          id?: string
          created_at?: string
          usuario_id?: string
          ubicacion_lat?: number
          ubicacion_lng?: number
          direccion_referencial?: string | null
          tipo_emergencia?: 'panico' | 'medica' | 'violencia' | 'robo_flagrancia' | 'accidente'
          descripcion?: string | null
          estado?: 'activa' | 'atendida' | 'cancelada' | 'falsa_alarma'
          tiempo_respuesta?: number | null
          contactos_notificados?: Json | null
          autoridades_notificadas?: Json | null
          resolucion?: string | null
          fecha_resolucion?: string | null
          calificacion?: number | null
        }
      }
      alertas_proximidad: {
        Row: {
          id: string
          created_at: string
          reporte_id: string | null
          emergencia_id: string | null
          ubicacion_lat: number
          ubicacion_lng: number
          radio_metros: number
          tipo_alerta: 'incidente' | 'emergencia' | 'prevencion'
          mensaje: string
          activa: boolean
          fecha_expiracion: string | null
          usuarios_notificados: Json | null
        }
        Insert: {
          id?: string
          created_at?: string
          reporte_id?: string | null
          emergencia_id?: string | null
          ubicacion_lat: number
          ubicacion_lng: number
          radio_metros: number
          tipo_alerta: 'incidente' | 'emergencia' | 'prevencion'
          mensaje: string
          activa?: boolean
          fecha_expiracion?: string | null
          usuarios_notificados?: Json | null
        }
        Update: {
          id?: string
          created_at?: string
          reporte_id?: string | null
          emergencia_id?: string | null
          ubicacion_lat?: number
          ubicacion_lng?: number
          radio_metros?: number
          tipo_alerta?: 'incidente' | 'emergencia' | 'prevencion'
          mensaje?: string
          activa?: boolean
          fecha_expiracion?: string | null
          usuarios_notificados?: Json | null
        }
      }
      recompensas: {
        Row: {
          id: string
          created_at: string
          usuario_id: string
          tipo_actividad: 'reporte' | 'verificacion' | 'testimonio' | 'colaboracion' | 'referido'
          puntos: number
          descripcion: string
          reporte_id: string | null
          canjeado: boolean
          fecha_canje: string | null
          premio_canjeado: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          usuario_id: string
          tipo_actividad: 'reporte' | 'verificacion' | 'testimonio' | 'colaboracion' | 'referido'
          puntos: number
          descripcion: string
          reporte_id?: string | null
          canjeado?: boolean
          fecha_canje?: string | null
          premio_canjeado?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          usuario_id?: string
          tipo_actividad?: 'reporte' | 'verificacion' | 'testimonio' | 'colaboracion' | 'referido'
          puntos?: number
          descripcion?: string
          reporte_id?: string | null
          canjeado?: boolean
          fecha_canje?: string | null
          premio_canjeado?: string | null
        }
      }
      consultas_ia: {
        Row: {
          id: string
          created_at: string
          usuario_id: string
          pregunta: string
          respuesta: string
          categoria: 'legal' | 'procedimiento' | 'emergencia' | 'general'
          calificacion: number | null
          tiempo_respuesta: number
          modelo_usado: string
        }
        Insert: {
          id?: string
          created_at?: string
          usuario_id: string
          pregunta: string
          respuesta: string
          categoria: 'legal' | 'procedimiento' | 'emergencia' | 'general'
          calificacion?: number | null
          tiempo_respuesta: number
          modelo_usado: string
        }
        Update: {
          id?: string
          created_at?: string
          usuario_id?: string
          pregunta?: string
          respuesta?: string
          categoria?: 'legal' | 'procedimiento' | 'emergencia' | 'general'
          calificacion?: number | null
          tiempo_respuesta?: number
          modelo_usado?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      obtener_reportes_cercanos: {
        Args: {
          lat: number
          lng: number
          radio_km: number
        }
        Returns: {
          id: string
          titulo: string
          tipo_incidente: string
          ubicacion_lat: number
          ubicacion_lng: number
          distancia_km: number
          created_at: string
        }[]
      }
      obtener_estadisticas_usuario: {
        Args: {
          user_id: string
        }
        Returns: {
          total_reportes: number
          reportes_resueltos: number
          puntos_totales: number
          nivel_usuario: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}

// Tipos utilitarios para JUSTIC.IA
export type Usuario = Database['public']['Tables']['usuarios']['Row']
export type Reporte = Database['public']['Tables']['reportes']['Row']
export type Emergencia = Database['public']['Tables']['emergencias']['Row']
export type AlertaProximidad = Database['public']['Tables']['alertas_proximidad']['Row']
export type Recompensa = Database['public']['Tables']['recompensas']['Row']
export type ConsultaIA = Database['public']['Tables']['consultas_ia']['Row']

export type InsertUsuario = Database['public']['Tables']['usuarios']['Insert']
export type InsertReporte = Database['public']['Tables']['reportes']['Insert']
export type InsertEmergencia = Database['public']['Tables']['emergencias']['Insert']
export type InsertAlertaProximidad = Database['public']['Tables']['alertas_proximidad']['Insert']
export type InsertRecompensa = Database['public']['Tables']['recompensas']['Insert']
export type InsertConsultaIA = Database['public']['Tables']['consultas_ia']['Insert']

export type UpdateUsuario = Database['public']['Tables']['usuarios']['Update']
export type UpdateReporte = Database['public']['Tables']['reportes']['Update']
export type UpdateEmergencia = Database['public']['Tables']['emergencias']['Update']