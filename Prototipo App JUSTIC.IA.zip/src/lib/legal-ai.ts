import { supabase, isSupabaseAvailable } from './supabase'
import { InsertConsultaIA } from './database.types'

// Función helper para obtener variables de entorno de forma segura
const getEnvVar = (key: string, fallback: string): string => {
  if (typeof window !== 'undefined') {
    const windowVar = (window as any)[key];
    if (windowVar) return windowVar;
  }
  return fallback;
}

// Configuración para OpenAI (cuando esté disponible)
const OPENAI_API_KEY = getEnvVar('NEXT_PUBLIC_OPENAI_API_KEY', 'demo-openai-key')
const MODELO_IA = 'gpt-4o-mini'

// Base de conocimiento legal para Perú
const CONOCIMIENTO_LEGAL = {
  constitucion: {
    articulo2: "Artículo 2°: Toda persona tiene derecho a la vida, a su integridad moral, psíquica y física y a su libre desarrollo y bienestar.",
    articulo2_24: "Artículo 2.24°: A la libertad y a la seguridad personales.",
    articulo139: "Artículo 139°: Principios y derechos de la función jurisdiccional."
  },
  codigoPenal: {
    robo: {
      articulo: "188°",
      definicion: "El que se apodera ilegítimamente de un bien mueble total o parcialmente ajeno, para aprovecharse de él, sustrayéndolo del lugar en que se encuentra, empleando violencia contra la persona o amenazándola con un peligro inminente para su vida o integridad física.",
      pena: "Pena privativa de libertad no menor de tres ni mayor de ocho años."
    },
    hurto: {
      articulo: "185°",
      definicion: "El que, para obtener provecho, se apodera ilegítimamente de un bien mueble, total o parcialmente ajeno, sustrayéndolo del lugar donde se encuentra.",
      pena: "Pena privativa de libertad no mayor de tres años."
    },
    acoso: {
      ley: "27942",
      definicion: "Conducta física o verbal de naturaleza sexual, indeseada o rechazada por la persona contra la que se dirige.",
      ambitos: "Laboral, educativo, prestación de servicios."
    },
    lesiones: {
      articulo: "121°",
      definicion: "El que causa a otro daño en el cuerpo o en la salud.",
      tipos: "Lesiones leves, graves, muy graves."
    }
  },
  procedimientos: {
    denuncia: {
      donde: ["Comisarías PNP", "Fiscalías Provinciales", "Plataforma digital del Ministerio Público"],
      documentos: ["DNI original y copia", "Declaración detallada", "Evidencias disponibles", "Certificado médico (si hay lesiones)"],
      plazo: "La mayoría de delitos prescriben, no demores en denunciar"
    },
    emergencia: {
      numeros: {
        "105": "Policía Nacional del Perú",
        "116": "Bomberos",
        "117": "SAMU - Emergencias médicas",
        "1818": "Serenazgo Municipal"
      },
      cuando: "Peligro inmediato, delito en flagrancia, emergencia médica"
    }
  }
}

// Servicio de IA Legal para JUSTIC.IA
export class LegalAIService {

  // Consultar al asistente legal
  static async consultarAsistenteIA(
    usuarioId: string,
    pregunta: string
  ): Promise<{
    success: boolean
    respuesta?: string
    categoria?: string
    tiempoRespuesta?: number
    error?: string
  }> {
    const tiempoInicio = Date.now()

    try {
      // Determinar categoría de la consulta
      const categoria = LegalAIService.categorizarConsulta(pregunta)
      
      let respuesta: string

      // Si tenemos OpenAI disponible, usar IA real
      if (OPENAI_API_KEY && OPENAI_API_KEY !== 'demo-openai-key') {
        respuesta = await LegalAIService.consultarOpenAI(pregunta, categoria)
      } else {
        // Usar respuestas basadas en conocimiento local
        respuesta = LegalAIService.generarRespuestaLocal(pregunta, categoria)
      }

      const tiempoRespuesta = Date.now() - tiempoInicio

      // Guardar consulta en la base de datos
      await LegalAIService.guardarConsulta(
        usuarioId,
        pregunta,
        respuesta,
        categoria,
        tiempoRespuesta
      )

      return {
        success: true,
        respuesta,
        categoria,
        tiempoRespuesta
      }

    } catch (error) {
      console.error('Error en consulta IA:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error procesando consulta'
      }
    }
  }

  // Categorizar consulta legal
  static categorizarConsulta(pregunta: string): 'legal' | 'procedimiento' | 'emergencia' | 'general' {
    const preguntaLower = pregunta.toLowerCase()

    // Emergencias
    if (preguntaLower.includes('emergencia') || 
        preguntaLower.includes('105') || 
        preguntaLower.includes('auxilio') ||
        preguntaLower.includes('peligro')) {
      return 'emergencia'
    }

    // Procedimientos
    if (preguntaLower.includes('denunciar') || 
        preguntaLower.includes('denuncia') ||
        preguntaLower.includes('cómo') ||
        preguntaLower.includes('donde') ||
        preguntaLower.includes('documentos') ||
        preguntaLower.includes('trámite')) {
      return 'procedimiento'
    }

    // Legal
    if (preguntaLower.includes('derecho') || 
        preguntaLower.includes('ley') ||
        preguntaLower.includes('artículo') ||
        preguntaLower.includes('código') ||
        preguntaLower.includes('constitución') ||
        preguntaLower.includes('pena') ||
        preguntaLower.includes('delito')) {
      return 'legal'
    }

    return 'general'
  }

  // Generar respuesta usando conocimiento local
  static generarRespuestaLocal(pregunta: string, categoria: string): string {
    const preguntaLower = pregunta.toLowerCase()

    // Respuestas sobre robo
    if (preguntaLower.includes('robo') || preguntaLower.includes('robaron')) {
      return `**Información Legal sobre Robo:**

📖 **Definición Legal (Art. ${CONOCIMIENTO_LEGAL.codigoPenal.robo.articulo} Código Penal):**
${CONOCIMIENTO_LEGAL.codigoPenal.robo.definicion}

⚖️ **Sanción:**
${CONOCIMIENTO_LEGAL.codigoPenal.robo.pena}

📋 **Procedimiento a seguir:**
1. Denuncia inmediata ante la PNP o Fiscalía
2. Solicitar certificado médico si hay lesiones
3. Recopilar evidencias (fotos, videos, testigos)
4. Seguimiento del caso con el fiscal asignado

📄 **Documentos necesarios:**
• ${CONOCIMIENTO_LEGAL.procedimientos.denuncia.documentos.join('\n• ')}

🚨 **Recomendación:** Si acabas de ser víctima, llama inmediatamente al 105 y activa el botón de emergencia en JUSTIC.IA.`
    }

    // Respuestas sobre acoso
    if (preguntaLower.includes('acoso') || preguntaLower.includes('hostigamiento')) {
      return `**Información Legal sobre Acoso Sexual:**

📖 **Marco Legal (Ley N° ${CONOCIMIENTO_LEGAL.codigoPenal.acoso.ley}):**
${CONOCIMIENTO_LEGAL.codigoPenal.acoso.definicion}

🏢 **Ámbitos de aplicación:**
${CONOCIMIENTO_LEGAL.codigoPenal.acoso.ambitos}

📋 **Procedimiento a seguir:**
1. Documentar los hechos (fechas, lugares, testigos)
2. Denuncia ante el Ministerio de Trabajo o PNP
3. En centros laborales, seguir protocolos internos
4. Solicitar medidas de protección

💡 **Tip:** Guarda todas las evidencias (mensajes, emails, testigos) y no dudes en denunciar. El acoso sexual es un delito grave.`
    }

    // Respuestas sobre emergencias
    if (preguntaLower.includes('emergencia') || preguntaLower.includes('105')) {
      const numeros = Object.entries(CONOCIMIENTO_LEGAL.procedimientos.emergencia.numeros)
        .map(([num, desc]) => `• **${num}**: ${desc}`)
        .join('\n')

      return `**Información sobre Emergencias:**

📞 **Números de Emergencia:**
${numeros}

🚨 **¿Cuándo llamar?**
${CONOCIMIENTO_LEGAL.procedimientos.emergencia.cuando}

⚡ **En JUSTIC.IA:**
Puedes usar el botón rojo de EMERGENCIA para activar automáticamente los protocolos de auxilio y notificar a tus contactos de emergencia.

⏱️ **Recuerda:** En emergencias cada segundo cuenta. No dudes en llamar al 105.`
    }

    // Respuestas sobre derechos constitucionales
    if (preguntaLower.includes('derecho') || preguntaLower.includes('constitucional')) {
      return `**Derechos Constitucionales Fundamentales:**

🏛️ **Principales derechos (Constitución de 1993):**

• **${CONOCIMIENTO_LEGAL.constitucion.articulo2}**

• **${CONOCIMIENTO_LEGAL.constitucion.articulo2_24}**

• **${CONOCIMIENTO_LEGAL.constitucion.articulo139}**

⚖️ **¿Vulneraron tus derechos?**
Puedes presentar acción de amparo ante el Poder Judicial para proteger tus derechos constitucionales.

💼 **Defensa Pública:**
Si no puedes costear un abogado, el Estado debe proporcionarte uno gratuitamente según el artículo 139° inciso 14 de la Constitución.`
    }

    // Respuestas sobre denuncias
    if (preguntaLower.includes('denunciar') || preguntaLower.includes('denuncia')) {
      const lugares = CONOCIMIENTO_LEGAL.procedimientos.denuncia.donde.join('\n• ')
      const documentos = CONOCIMIENTO_LEGAL.procedimientos.denuncia.documentos.join('\n• ')

      return `**Cómo realizar una denuncia:**

📍 **¿Dónde denunciar?**
• ${lugares}

📄 **Documentos necesarios:**
• ${documentos}

⏰ **Tiempo límite:**
${CONOCIMIENTO_LEGAL.procedimientos.denuncia.plazo}

💡 **En JUSTIC.IA:**
Puedes generar un pre-reporte digital que te ayudará a organizar toda la información antes de ir a denunciar presencialmente.

🎯 **Tip:** Mientras más detalles proporciones, mejor será la investigación.`
    }

    // Respuesta general
    return `Hola, soy Justiciero, tu asistente legal inteligente especializado en el sistema jurídico peruano.

🔹 **Puedo ayudarte con:**
• Procedimientos legales (denuncias, trámites)
• Derechos constitucionales y garantías
• Información sobre delitos del Código Penal
• Pasos a seguir en casos específicos
• Números de emergencia y cuándo usarlos

¿Podrías ser más específico sobre tu consulta? Por ejemplo:
• "¿Qué hacer si me robaron?"
• "¿Cuáles son mis derechos si me detiene la policía?"
• "¿Cómo denunciar violencia doméstica?"

💡 **Recuerda:** Esta es información general basada en la legislación peruana. Para casos complejos, consulta con un abogado especializado.`
  }

  // Consultar OpenAI (cuando esté disponible)
  static async consultarOpenAI(pregunta: string, categoria: string): Promise<string> {
    try {
      const prompt = `Eres Justiciero, asistente legal de JUSTIC.IA, especializado en el sistema jurídico peruano.

CONTEXTO:
- Estás especializado en la Constitución Política del Perú de 1993
- Conoces el Código Penal peruano actualizado
- Sabes sobre procedimientos de denuncia ante PNP y Ministerio Público
- Proporcionas información práctica y accesible

INSTRUCCIONES:
- Responde en español con terminología legal peruana
- Cita artículos específicos cuando sea relevante
- Da pasos prácticos y accionables
- Incluye números de emergencia cuando sea apropiado
- Mantén un tono profesional pero accesible

CATEGORÍA DE CONSULTA: ${categoria}

PREGUNTA DEL USUARIO: ${pregunta}

Responde de manera clara, específica y útil para el contexto peruano:`

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: MODELO_IA,
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 800,
          temperature: 0.7
        })
      })

      if (!response.ok) {
        throw new Error('Error consultando OpenAI')
      }

      const data = await response.json()
      return data.choices[0].message.content

    } catch (error) {
      console.error('Error con OpenAI:', error)
      // Fallback a respuesta local
      return LegalAIService.generarRespuestaLocal(pregunta, categoria)
    }
  }

  // Guardar consulta en la base de datos
  static async guardarConsulta(
    usuarioId: string,
    pregunta: string,
    respuesta: string,
    categoria: string,
    tiempoRespuesta: number
  ): Promise<void> {
    try {
      // Solo guardar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        console.log('💾 Consulta IA no guardada - modo demo');
        return;
      }

      const nuevaConsulta: InsertConsultaIA = {
        usuario_id: usuarioId,
        pregunta,
        respuesta,
        categoria: categoria as any,
        tiempo_respuesta: tiempoRespuesta,
        modelo_usado: OPENAI_API_KEY ? MODELO_IA : 'local'
      }

      await supabase!
        .from('consultas_ia')
        .insert(nuevaConsulta)

    } catch (error) {
      console.error('Error guardando consulta:', error)
    }
  }

  // Obtener historial de consultas del usuario
  static async obtenerHistorialConsultas(usuarioId: string): Promise<{
    success: boolean
    consultas?: any[]
    error?: string
  }> {
    try {
      // Solo obtener historial si Supabase está disponible
      if (!isSupabaseAvailable()) {
        return {
          success: true,
          consultas: [] // Retornar array vacío en modo demo
        };
      }

      const { data: consultas, error } = await supabase!
        .from('consultas_ia')
        .select('*')
        .eq('usuario_id', usuarioId)
        .order('created_at', { ascending: false })
        .limit(20)

      if (error) {
        throw new Error(error.message)
      }

      return {
        success: true,
        consultas: consultas || []
      }

    } catch (error) {
      console.error('Error obteniendo historial:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }

  // Calificar respuesta de IA
  static async calificarRespuesta(
    consultaId: string,
    calificacion: number
  ): Promise<{ success: boolean; error?: string }> {
    try {
      // Solo calificar si Supabase está disponible
      if (!isSupabaseAvailable()) {
        console.log('⭐ Calificación no guardada - modo demo');
        return { success: true };
      }

      const { error } = await supabase!
        .from('consultas_ia')
        .update({ calificacion })
        .eq('id', consultaId)

      if (error) {
        throw new Error(error.message)
      }

      return { success: true }

    } catch (error) {
      console.error('Error calificando respuesta:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
    }
  }
}