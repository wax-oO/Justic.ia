import React, { useState, useEffect } from 'react';
import { MobileLayout } from './components/layout/mobile-layout';
import { BottomNav } from './components/navigation/bottom-nav';
import { HomeScreen } from './components/screens/home-screen';
import { ReportsScreen } from './components/screens/reports-screen';
import { MapScreen } from './components/screens/map-screen';
import { ProfileScreen } from './components/screens/profile-screen';
import { AuthScreen } from './components/screens/auth-screen';
import { DemoAuthScreen } from './components/screens/demo-auth-screen';
import { LegalAIScreen } from './components/screens/legal-ai-screen';
import { CreateReportScreen } from './components/screens/create-report-screen';
import { AuthService } from './lib/auth';
import { Usuario } from './lib/database.types';
import { verificarConexionSupabase } from './lib/supabase';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userData, setUserData] = useState<Usuario | null>(null);
  const [isEmergencyMode, setIsEmergencyMode] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [supabaseConnected, setSupabaseConnected] = useState(false);

  // Verificar conexión a Supabase y usuario autenticado al iniciar
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Verificar conexión a Supabase
        const connected = await verificarConexionSupabase();
        setSupabaseConnected(connected);

        // Si hay conexión, verificar si hay usuario autenticado
        if (connected) {
          const response = await AuthService.obtenerUsuarioActual();
          if (response.success && response.usuario) {
            setUserData(response.usuario);
            setIsAuthenticated(true);
          }
        }
      } catch (error) {
        console.error('Error inicializando app:', error);
        // En caso de error, asumir modo demo
        setSupabaseConnected(false);
      } finally {
        setIsLoading(false);
      }
    };

    initializeApp();
  }, []);

  const handleAuthenticated = (user: Usuario) => {
    setUserData(user);
    setIsAuthenticated(true);
    setIsEmergencyMode(false);
  };

  const handleEmergencyAccess = () => {
    // Crear usuario temporal para modo emergencia
    const emergencyUser = AuthService.crearUsuarioEmergencia();
    
    setUserData(emergencyUser);
    setIsAuthenticated(true);
    setIsEmergencyMode(true);
    setActiveTab('home'); // Ir directo al botón de pánico
  };

  const handleLogout = async () => {
    try {
      if (!isEmergencyMode && supabaseConnected) {
        await AuthService.cerrarSesion();
      }
      
      setIsAuthenticated(false);
      setUserData(null);
      setIsEmergencyMode(false);
      setActiveTab('home');
    } catch (error) {
      console.error('Error en logout:', error);
      // Forzar logout local si falla el remoto
      setIsAuthenticated(false);
      setUserData(null);
      setIsEmergencyMode(false);
      setActiveTab('home');
    }
  };

  const handleNavigate = (screen: string) => {
    setActiveTab(screen);
  };

  // Pantalla de carga
  if (isLoading) {
    return (
      <MobileLayout>
        <div className="h-screen flex items-center justify-center bg-background">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <h2 className="text-xl mb-2">JUSTIC.IA</h2>
            <p className="text-muted-foreground">Iniciando aplicación...</p>
            {!supabaseConnected && (
              <p className="text-orange-600 text-sm mt-2">
                ⚠️ Modo offline - Algunas funciones limitadas
              </p>
            )}
          </div>
        </div>
      </MobileLayout>
    );
  }

  // Si no está autenticado, mostrar pantalla de autenticación
  if (!isAuthenticated) {
    // Usar DemoAuthScreen si no hay Supabase, AuthScreen si sí hay
    return supabaseConnected ? (
      <AuthScreen 
        onAuthenticated={handleAuthenticated}
        onEmergencyAccess={handleEmergencyAccess}
        supabaseConnected={supabaseConnected}
      />
    ) : (
      <DemoAuthScreen 
        onAuthenticated={handleAuthenticated}
        onEmergencyAccess={handleEmergencyAccess}
        supabaseConnected={supabaseConnected}
      />
    );
  }

  const renderActiveScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen onNavigate={handleNavigate} userData={userData} isEmergencyMode={isEmergencyMode} />;
      case 'reports':
        return <ReportsScreen userData={userData} onNavigate={handleNavigate} />;
      case 'map':
        return <MapScreen userData={userData} onNavigate={handleNavigate} />;
      case 'profile':
        return <ProfileScreen userData={userData} onLogout={handleLogout} isEmergencyMode={isEmergencyMode} onNavigate={handleNavigate} />;
      case 'legal-ai':
        return <LegalAIScreen userData={userData} onNavigate={handleNavigate} />;
      case 'create-report':
        return <CreateReportScreen userData={userData} onNavigate={handleNavigate} />;
      default:
        return <HomeScreen onNavigate={handleNavigate} userData={userData} isEmergencyMode={isEmergencyMode} />;
    }
  };

  return (
    <MobileLayout>
      <div className="h-screen flex flex-col">
        <div className="flex-1">
          {renderActiveScreen()}
        </div>
        {/* Solo mostrar bottom nav en las pantallas principales */}
        {['home', 'reports', 'map', 'profile'].includes(activeTab) && (
          <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
        )}
      </div>
    </MobileLayout>
  );
}