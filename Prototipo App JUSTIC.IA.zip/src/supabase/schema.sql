-- Schema SQL para JUSTIC.IA en Supabase
-- Ejecutar este script en el SQL Editor de Supabase

-- Habilitar extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    dni VARCHAR(8) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    fecha_nacimiento DATE,
    direccion TEXT,
    distrito VARCHAR(100),
    provincia VARCHAR(100),
    departamento VARCHAR(100),
    verificado_reniec BOOLEAN DEFAULT FALSE,
    verificado_email BOOLEAN DEFAULT FALSE,
    verificado_telefono BOOLEAN DEFAULT FALSE,
    avatar_url TEXT,
    es_emergencia BOOLEAN DEFAULT FALSE,
    estado VARCHAR(20) DEFAULT 'activo' CHECK (estado IN ('activo', 'inactivo', 'suspendido')),
    ultima_actividad TIMESTAMP WITH TIME ZONE,
    configuracion_privacidad JSONB,
    contactos_emergencia JSONB DEFAULT '[]'::jsonb,
    auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Trigger para updated_at en usuarios
CREATE TRIGGER update_usuarios_updated_at
    BEFORE UPDATE ON usuarios
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Tabla de reportes
CREATE TABLE IF NOT EXISTS reportes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE NOT NULL,
    tipo_incidente VARCHAR(50) NOT NULL CHECK (tipo_incidente IN ('robo', 'acoso', 'agresion', 'extorsion', 'emergencia', 'otro')),
    subtipo VARCHAR(100),
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT NOT NULL,
    ubicacion_lat DECIMAL(10, 8) NOT NULL,
    ubicacion_lng DECIMAL(11, 8) NOT NULL,
    direccion_referencial TEXT,
    distrito VARCHAR(100),
    provincia VARCHAR(100),
    departamento VARCHAR(100),
    fecha_incidente DATE NOT NULL,
    hora_incidente TIME,
    evidencias JSONB DEFAULT '[]'::jsonb,
    testigos JSONB DEFAULT '[]'::jsonb,
    agresor_descripcion TEXT,
    vehiculo_descripcion TEXT,
    objetos_sustraidos JSONB DEFAULT '[]'::jsonb,
    monto_aproximado DECIMAL(10, 2),
    codigo_qr VARCHAR(100) UNIQUE NOT NULL,
    codigo_seguimiento VARCHAR(50) UNIQUE NOT NULL,
    estado VARCHAR(20) DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'en_proceso', 'resuelto', 'cerrado', 'rechazado')),
    prioridad VARCHAR(20) DEFAULT 'media' CHECK (prioridad IN ('baja', 'media', 'alta', 'critica')),
    visible_publico BOOLEAN DEFAULT TRUE,
    denuncia_pnp VARCHAR(100),
    seguimiento_pnp JSONB DEFAULT '{}'::jsonb,
    calificacion_usuario INTEGER CHECK (calificacion_usuario >= 1 AND calificacion_usuario <= 5),
    comentario_usuario TEXT,
    asignado_a UUID,
    resolucion TEXT,
    fecha_resolucion TIMESTAMP WITH TIME ZONE
);

-- Trigger para updated_at en reportes
CREATE TRIGGER update_reportes_updated_at
    BEFORE UPDATE ON reportes
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Tabla de emergencias
CREATE TABLE IF NOT EXISTS emergencias (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE NOT NULL,
    ubicacion_lat DECIMAL(10, 8) NOT NULL,
    ubicacion_lng DECIMAL(11, 8) NOT NULL,
    direccion_referencial TEXT,
    tipo_emergencia VARCHAR(50) NOT NULL CHECK (tipo_emergencia IN ('panico', 'medica', 'violencia', 'robo_flagrancia', 'accidente')),
    descripcion TEXT,
    estado VARCHAR(20) DEFAULT 'activa' CHECK (estado IN ('activa', 'atendida', 'cancelada', 'falsa_alarma')),
    tiempo_respuesta INTEGER, -- en minutos
    contactos_notificados JSONB DEFAULT '[]'::jsonb,
    autoridades_notificadas JSONB DEFAULT '[]'::jsonb,
    resolucion TEXT,
    fecha_resolucion TIMESTAMP WITH TIME ZONE,
    calificacion INTEGER CHECK (calificacion >= 1 AND calificacion <= 5)
);

-- Tabla de alertas de proximidad
CREATE TABLE IF NOT EXISTS alertas_proximidad (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reporte_id UUID REFERENCES reportes(id) ON DELETE CASCADE,
    emergencia_id UUID REFERENCES emergencias(id) ON DELETE CASCADE,
    ubicacion_lat DECIMAL(10, 8) NOT NULL,
    ubicacion_lng DECIMAL(11, 8) NOT NULL,
    radio_metros INTEGER NOT NULL DEFAULT 500,
    tipo_alerta VARCHAR(20) NOT NULL CHECK (tipo_alerta IN ('incidente', 'emergencia', 'prevencion')),
    mensaje TEXT NOT NULL,
    activa BOOLEAN DEFAULT TRUE,
    fecha_expiracion TIMESTAMP WITH TIME ZONE,
    usuarios_notificados JSONB DEFAULT '[]'::jsonb,
    CHECK (reporte_id IS NOT NULL OR emergencia_id IS NOT NULL)
);

-- Tabla de recompensas
CREATE TABLE IF NOT EXISTS recompensas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE NOT NULL,
    tipo_actividad VARCHAR(50) NOT NULL CHECK (tipo_actividad IN ('reporte', 'verificacion', 'testimonio', 'colaboracion', 'referido')),
    puntos INTEGER NOT NULL DEFAULT 0,
    descripcion TEXT NOT NULL,
    reporte_id UUID REFERENCES reportes(id) ON DELETE SET NULL,
    canjeado BOOLEAN DEFAULT FALSE,
    fecha_canje TIMESTAMP WITH TIME ZONE,
    premio_canjeado TEXT
);

-- Tabla de consultas IA
CREATE TABLE IF NOT EXISTS consultas_ia (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE NOT NULL,
    pregunta TEXT NOT NULL,
    respuesta TEXT NOT NULL,
    categoria VARCHAR(20) NOT NULL CHECK (categoria IN ('legal', 'procedimiento', 'emergencia', 'general')),
    calificacion INTEGER CHECK (calificacion >= 1 AND calificacion <= 5),
    tiempo_respuesta INTEGER NOT NULL, -- en milisegundos
    modelo_usado VARCHAR(50) NOT NULL DEFAULT 'local'
);

-- Índices para optimizar consultas
CREATE INDEX IF NOT EXISTS idx_usuarios_dni ON usuarios(dni);
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_auth_user_id ON usuarios(auth_user_id);

CREATE INDEX IF NOT EXISTS idx_reportes_usuario_id ON reportes(usuario_id);
CREATE INDEX IF NOT EXISTS idx_reportes_tipo_incidente ON reportes(tipo_incidente);
CREATE INDEX IF NOT EXISTS idx_reportes_estado ON reportes(estado);
CREATE INDEX IF NOT EXISTS idx_reportes_ubicacion ON reportes(ubicacion_lat, ubicacion_lng);
CREATE INDEX IF NOT EXISTS idx_reportes_fecha_incidente ON reportes(fecha_incidente);
CREATE INDEX IF NOT EXISTS idx_reportes_codigo_qr ON reportes(codigo_qr);
CREATE INDEX IF NOT EXISTS idx_reportes_codigo_seguimiento ON reportes(codigo_seguimiento);

CREATE INDEX IF NOT EXISTS idx_emergencias_usuario_id ON emergencias(usuario_id);
CREATE INDEX IF NOT EXISTS idx_emergencias_estado ON emergencias(estado);
CREATE INDEX IF NOT EXISTS idx_emergencias_ubicacion ON emergencias(ubicacion_lat, ubicacion_lng);

CREATE INDEX IF NOT EXISTS idx_alertas_proximidad_ubicacion ON alertas_proximidad(ubicacion_lat, ubicacion_lng);
CREATE INDEX IF NOT EXISTS idx_alertas_proximidad_activa ON alertas_proximidad(activa);

CREATE INDEX IF NOT EXISTS idx_recompensas_usuario_id ON recompensas(usuario_id);
CREATE INDEX IF NOT EXISTS idx_recompensas_tipo_actividad ON recompensas(tipo_actividad);

CREATE INDEX IF NOT EXISTS idx_consultas_ia_usuario_id ON consultas_ia(usuario_id);
CREATE INDEX IF NOT EXISTS idx_consultas_ia_categoria ON consultas_ia(categoria);

-- Función para obtener reportes cercanos
CREATE OR REPLACE FUNCTION obtener_reportes_cercanos(
    lat DECIMAL,
    lng DECIMAL,
    radio_km DECIMAL DEFAULT 5
)
RETURNS TABLE (
    id UUID,
    titulo VARCHAR,
    tipo_incidente VARCHAR,
    ubicacion_lat DECIMAL,
    ubicacion_lng DECIMAL,
    distancia_km DECIMAL,
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.id,
        r.titulo,
        r.tipo_incidente,
        r.ubicacion_lat,
        r.ubicacion_lng,
        (6371 * acos(cos(radians(lat)) * cos(radians(r.ubicacion_lat)) * 
         cos(radians(r.ubicacion_lng) - radians(lng)) + 
         sin(radians(lat)) * sin(radians(r.ubicacion_lat)))) AS distancia_km,
        r.created_at
    FROM reportes r
    WHERE r.visible_publico = TRUE
    AND r.estado IN ('pendiente', 'en_proceso')
    AND (6371 * acos(cos(radians(lat)) * cos(radians(r.ubicacion_lat)) * 
         cos(radians(r.ubicacion_lng) - radians(lng)) + 
         sin(radians(lat)) * sin(radians(r.ubicacion_lat)))) <= radio_km
    ORDER BY distancia_km;
END;
$$ LANGUAGE plpgsql;

-- Función para obtener estadísticas del usuario
CREATE OR REPLACE FUNCTION obtener_estadisticas_usuario(user_id UUID)
RETURNS TABLE (
    total_reportes BIGINT,
    reportes_resueltos BIGINT,
    puntos_totales BIGINT,
    nivel_usuario TEXT
) AS $$
DECLARE
    puntos BIGINT;
BEGIN
    -- Contar reportes totales
    SELECT COUNT(*) INTO total_reportes
    FROM reportes r
    WHERE r.usuario_id = user_id;

    -- Contar reportes resueltos
    SELECT COUNT(*) INTO reportes_resueltos
    FROM reportes r
    WHERE r.usuario_id = user_id
    AND r.estado = 'resuelto';

    -- Sumar puntos totales
    SELECT COALESCE(SUM(puntos), 0) INTO puntos_totales
    FROM recompensas re
    WHERE re.usuario_id = user_id;

    -- Determinar nivel del usuario
    puntos := puntos_totales;
    IF puntos >= 1000 THEN
        nivel_usuario := 'Experto';
    ELSIF puntos >= 500 THEN
        nivel_usuario := 'Avanzado';
    ELSIF puntos >= 100 THEN
        nivel_usuario := 'Intermedio';
    ELSE
        nivel_usuario := 'Principiante';
    END IF;

    RETURN NEXT;
END;
$$ LANGUAGE plpgsql;

-- RLS (Row Level Security) para seguridad
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE reportes ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergencias ENABLE ROW LEVEL SECURITY;
ALTER TABLE recompensas ENABLE ROW LEVEL SECURITY;
ALTER TABLE consultas_ia ENABLE ROW LEVEL SECURITY;

-- Políticas de seguridad para usuarios
CREATE POLICY "Los usuarios pueden ver su propio perfil" ON usuarios
    FOR SELECT USING (auth.uid() = auth_user_id);

CREATE POLICY "Los usuarios pueden actualizar su propio perfil" ON usuarios
    FOR UPDATE USING (auth.uid() = auth_user_id);

-- Políticas de seguridad para reportes
CREATE POLICY "Los usuarios pueden ver reportes públicos" ON reportes
    FOR SELECT USING (visible_publico = TRUE OR usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

CREATE POLICY "Los usuarios pueden crear sus propios reportes" ON reportes
    FOR INSERT WITH CHECK (usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

CREATE POLICY "Los usuarios pueden actualizar sus propios reportes" ON reportes
    FOR UPDATE USING (usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

-- Políticas de seguridad para emergencias
CREATE POLICY "Los usuarios pueden ver emergencias activas públicas" ON emergencias
    FOR SELECT USING (estado = 'activa' OR usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

CREATE POLICY "Los usuarios pueden crear sus propias emergencias" ON emergencias
    FOR INSERT WITH CHECK (usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

-- Políticas de seguridad para recompensas
CREATE POLICY "Los usuarios pueden ver sus propias recompensas" ON recompensas
    FOR SELECT USING (usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

-- Políticas de seguridad para consultas IA
CREATE POLICY "Los usuarios pueden ver sus propias consultas" ON consultas_ia
    FOR SELECT USING (usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

CREATE POLICY "Los usuarios pueden crear consultas IA" ON consultas_ia
    FOR INSERT WITH CHECK (usuario_id IN (
        SELECT id FROM usuarios WHERE auth_user_id = auth.uid()
    ));

-- Funciones de trigger para lógica de negocio
CREATE OR REPLACE FUNCTION generar_codigo_qr()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.codigo_qr IS NULL OR NEW.codigo_qr = '' THEN
        NEW.codigo_qr := 'JUSTIC-' || extract(epoch from now())::bigint || '-' || substr(md5(random()::text), 1, 8);
    END IF;
    
    IF NEW.codigo_seguimiento IS NULL OR NEW.codigo_seguimiento = '' THEN
        NEW.codigo_seguimiento := 'REP-' || substr(extract(epoch from now())::text, -8);
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para generar códigos automáticamente
CREATE TRIGGER trigger_generar_codigos
    BEFORE INSERT ON reportes
    FOR EACH ROW
    EXECUTE FUNCTION generar_codigo_qr();

-- Insertar datos de ejemplo (opcional)
INSERT INTO usuarios (dni, nombre, apellidos, email, telefono, es_emergencia) VALUES
('12345678', 'Demo', 'Usuario', 'demo@justic.ia', '987654321', false)
ON CONFLICT DO NOTHING;

-- Comentarios de documentación
COMMENT ON TABLE usuarios IS 'Tabla principal de usuarios registrados en JUSTIC.IA';
COMMENT ON TABLE reportes IS 'Reportes de incidentes creados por los usuarios';
COMMENT ON TABLE emergencias IS 'Emergencias activadas a través del botón de pánico';
COMMENT ON TABLE alertas_proximidad IS 'Sistema de alertas basado en proximidad geográfica';
COMMENT ON TABLE recompensas IS 'Sistema de puntos y recompensas por participación cívica';
COMMENT ON TABLE consultas_ia IS 'Historial de consultas al asistente legal IA';

-- Completado: Schema de base de datos para JUSTIC.IA
-- Próximos pasos:
-- 1. Ejecutar este script en Supabase SQL Editor
-- 2. Configurar las variables de entorno
-- 3. Probar las conexiones desde la aplicación