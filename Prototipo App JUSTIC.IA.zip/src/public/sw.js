// Service Worker para JUSTIC.IA PWA
const CACHE_NAME = 'justicia-v1.0.0';
const urlsToCache = [
  '/',
  '/styles/globals.css',
  '/App.tsx',
  // Agregar otros recursos estáticos necesarios
];

// Instalación del service worker
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('Cache abierto');
        return cache.addAll(urlsToCache);
      })
  );
});

// Interceptar peticiones de red
self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request)
      .then(function(response) {
        // Si está en cache, devolver desde cache
        if (response) {
          return response;
        }
        
        // Si no, hacer petición de red
        return fetch(event.request).catch(function() {
          // Si falla la red y es una navegación, mostrar página offline
          if (event.request.destination === 'document') {
            return caches.match('/');
          }
        });
      })
  );
});

// Actualizar service worker
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});