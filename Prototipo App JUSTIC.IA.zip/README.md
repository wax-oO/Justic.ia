
  # Prototipo App JUSTIC.IA

  This is a code bundle for Prototipo App JUSTIC.IA. The original project is available at https://www.figma.com/design/5dJBUbxK8v9O6TYagGMRkC/Prototipo-App-JUSTIC.IA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  